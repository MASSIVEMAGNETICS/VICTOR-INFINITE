# SpeechSynthNode placeholder
class SpeechSynthNode: pass