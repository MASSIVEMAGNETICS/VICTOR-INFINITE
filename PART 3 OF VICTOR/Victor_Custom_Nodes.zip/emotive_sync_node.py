# EmotiveSyncNode placeholder
class EmotiveSyncNode: pass