# VictorNlpEngineNode placeholder
class VictorNlpEngineNode: pass