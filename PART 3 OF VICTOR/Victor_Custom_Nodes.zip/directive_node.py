# DirectiveNode placeholder
class DirectiveNode: pass