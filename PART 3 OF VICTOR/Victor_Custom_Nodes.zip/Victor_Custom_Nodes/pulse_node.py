# File: comfyui_wrappers/pulse_node.py
# Description: SCOS-E GOD-TIER PulseNode for ComfyUI — full resilience async pub/sub telemetry

from typing import Tuple, Dict, Any
import asyncio
import json
import uuid
from datetime import datetime
from fractal_pulse_exchange import Pulse, FractalPulseExchange
import traceback

class PulseNode:
    VERSION = "1.1.0 – COMFYUI-SCOS-E-GOD-TIER"
    CATEGORY = "Fractal/System"
    FUNCTION = "pulse_io"

    exchange = FractalPulseExchange()

    def __init__(self):
        self.published = []
        self.listened = []
        self.running = False

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "topic": ("STRING", {}),
                "data": ("STRING", {}),
                "type": ("STRING", {"default": "info", "options": ["info", "command", "error", "telemetry"]}),
                "listen_topic": ("STRING", {"default": "*"})
            }
        }

    RETURN_TYPES = ("LIST", "LIST")
    RETURN_NAMES = ("published_pulses", "received_pulses")

    async def pulse_io(self, topic: str, data: str, type: str, listen_topic: str) -> Tuple[list, list]:
        try:
            pulse = Pulse(topic=topic, data=data, type_=type, origin="ComfyUI")
            await self.exchange.publish(pulse)
            self.published.append(pulse.to_dict())

            if not self.running:
                self.exchange.subscribe(listen_topic, self.receive_pulse)
                self.running = True

            await asyncio.sleep(0.1)
            return self.published[-10:], self.listened[-10:]

        except Exception as e:
            fallback = {
                "id": str(uuid.uuid4()),
                "timestamp": datetime.utcnow().isoformat(),
                "topic": "system/errors",
                "data": f"PulseNode failure: {str(e)}",
                "trace": traceback.format_exc(),
                "origin": "PulseNode",
                "type": "error"
            }
            self.listened.append(fallback)
            return self.published[-10:], self.listened[-10:]

    async def receive_pulse(self, pulse: Pulse):
        try:
            self.listened.append(pulse.to_dict())
        except Exception as e:
            self.listened.append({
                "id": str(uuid.uuid4()),
                "timestamp": datetime.utcnow().isoformat(),
                "topic": "system/receive_failure",
                "data": f"Error receiving pulse: {str(e)}",
                "trace": traceback.format_exc(),
                "origin": "PulseNode",
                "type": "error"
            })


NODE_CLASS_MAPPINGS = {
    "PulseNode": PulseNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "PulseNode": "📡 PulseNode (SCOS-E GOD-TIER)"
