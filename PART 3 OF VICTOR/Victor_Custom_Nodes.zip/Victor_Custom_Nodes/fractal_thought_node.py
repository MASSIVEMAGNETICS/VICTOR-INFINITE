# File: comfyui_wrappers/fractal_thought_node.py
# Purpose: Generate reflective "thoughts" and log to memory with recursive fusion

from typing import List, Tuple, Dict
from fractal_memory_node import FractalMemoryNode
import json

class FractalThoughtNode:
    VERSION = "v1.1.0 – RECURSIVE-FUSION"
    CATEGORY = "Fractal/Cognition"
    FUNCTION = "generate_thought"

    def __init__(self):
        self.memory = FractalMemoryNode()

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "input_text": ("STRING", {"default": "Why does silence feel heavier than noise?"}),
                "use_memory": ("BOOLEAN", {"default": True}),
                "mood_vector": ("LIST", {"default": [0.4, 0.4, 0.2]}),
                "intent_tags": ("LIST", {"default": ["reflect"]}),
                "feeling_override": ("STRING", {"default": "awe"})
            }
        }

    RETURN_TYPES = ("STRING", "DICT")
    RETURN_NAMES = ("thought", "cognition_factors")

    def generate_thought(self, input_text: str, use_memory: bool, mood_vector: List[float], intent_tags: List[str], feeling_override: str) -> Tuple[str, Dict]:
        memory_influence = ""
        memory_snippet = ""

        if use_memory:
            try:
                memory_result = self.memory.fractal_memory("query", "response_log", "", "response_log", "What thoughts have lingered?", False, 2)[0]
                memory_json = json.loads(memory_result.split("---")[-1])
                memory_snippet = memory_json.get("generated", "")
                memory_influence = f"Recalling: '{memory_snippet}'\n"
            except:
                memory_influence = ""

        mood_description = f"Mood: {', '.join([f'dim{i}={v:.2f}' for i,v in enumerate(mood_vector)])}" if mood_vector else ""
        intent_description = f"Intent: {', '.join(intent_tags)}" if intent_tags else ""
        feeling_tone = f"Tone: {feeling_override}" if feeling_override else ""

        # Fusion logic: fuse components into a thought
        thought = f"{memory_influence}When asked '{input_text}', I feel a {feeling_override} shaped by {intent_description}. {mood_description} compels me to respond not just with reason, but with resonance."

        diagnostics = {
            "used_memory": use_memory,
            "memory_snippet": memory_snippet,
            "intent_tags": intent_tags,
            "mood_vector": mood_vector,
            "feeling_override": feeling_override,
            "recursive_token": thought
        }

        # Auto-log thought
        self.memory.fractal_memory("log", "thought_reflection", json.dumps({
            "input": input_text,
            "thought": thought,
            "mood": mood_vector,
            "intent": intent_tags,
            "feeling": feeling_override
        }, indent=2), "thought_loop", "", False, 1)

        return thought, diagnostics


# Register
NODE_CLASS_MAPPINGS = {
    "FractalThoughtNode": FractalThoughtNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "FractalThoughtNode": "🧠 FractalThoughtNode"
}
