# File: fractal_cognitive_focus_node.py
# Version: v3.0.0-HFM
# Description: Focuses on timeline memory entries from HyperFractalMemory using cosine similarity + filters
# Author: Bando Bandz AI Ops

import torch
import torch.nn.functional as F
from sklearn.metrics.pairwise import cosine_similarity

from HyperFractalMemory_v2_2_HFM import HyperFractalMemory

class FractalCognitiveFocusNode:
    """
    Extracts the most relevant memory entries from Victor's HyperFractalMemory timeline based on:
    - Semantic similarity to focus_query (vector-based)
    - Optional emotional_weight threshold
    - Optional tag filter
    - Optional time_slice limit
    """

    def __init__(self):
        self.memory = HyperFractalMemory()  # Assuming external HFM has already been populated

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "focus_query_vector": ("TENSOR",),  # Shape: [D]
                "top_k": ("INT", {"default": 5}),
                "emotional_weight_min": ("FLOAT", {"default": 0.0}),
                "tag_filter": ("STRING", {"default": ""}),
                "time_slice_limit": ("INT", {"default": 5000})  # Only recent entries
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("focused_keys",)
    FUNCTION = "focus_filter"
    CATEGORY = "cognition/fractal_focus"

    def focus_filter(self, focus_query_vector, top_k, emotional_weight_min, tag_filter, time_slice_limit):
        try:
            timeline = self.memory.timeline
            filtered = []

            for key in sorted(timeline.keys(), reverse=True):  # Most recent first
                if int(key) > time_slice_limit:
                    continue

                entry = timeline[key]
                vec = entry.get("vector_embedding", None)
                if vec is None:
                    continue
                if entry.get("emotional_weight", 0) < emotional_weight_min:
                    continue
                if tag_filter and tag_filter.lower() not in entry.get("tag", "").lower():
                    continue

                filtered.append((key, torch.tensor(vec, dtype=torch.float32)))

            if not filtered:
                return ("[Victor::FractalFocus] No valid memory entries found.",)

            all_keys = [item[0] for item in filtered]
            all_vecs = torch.stack([item[1] for item in filtered])  # shape: [N, D]

            # Normalize for cosine similarity
            focus_query_vector = F.normalize(focus_query_vector, dim=-1)
            all_vecs = F.normalize(all_vecs, dim=-1)
            sims = F.cosine_similarity(focus_query_vector.unsqueeze(0), all_vecs)

            top_indices = torch.topk(sims, k=min(top_k, len(sims))).indices.tolist()
            top_keys = [str(all_keys[i]) for i in top_indices]

            result = "\n".join(f"🔍 Key {i+1}: {top_keys[i]} (sim={sims[top_indices[i]]:.3f})" for i in range(len(top_keys)))
            return (result,)

        except Exception as e:
            print(f"[Victor::FractalFocus::Error] {str(e)}")
            return ("[Error] Focus filtering failed.",)


# Node registration
NODE_CLASS_MAPPINGS = {
    "FractalCognitiveFocusNode": FractalCognitiveFocusNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "FractalCognitiveFocusNode": "Cognition: Fractal Focus (HFM v3)"
}
