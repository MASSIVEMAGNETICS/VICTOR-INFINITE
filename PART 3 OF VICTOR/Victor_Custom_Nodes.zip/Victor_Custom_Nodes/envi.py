python -m venv fractal_env
cd fractal_env/Scripts
activate  # For Windows
