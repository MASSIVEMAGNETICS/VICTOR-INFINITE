# File: cognitive_trend_tracker_node.py
# Version: v3.0.0-FP
# Description: Full fault-tolerant cognitive tracking engine with regeneration and dual-backup memory
# Author: Bando Bandz AI Ops

import os
import matplotlib.pyplot as plt
import uuid
import time
import json
from shutil import copyfile

class CognitiveTrendTrackerNode:
    """
    Logs Victor’s self-evaluation history over time with regenerative log recovery,
    dual redundancy, and continuous timeline support.
    """

    def __init__(self):
        self.base_dir = "cognitive_trends/"
        self.primary_log = os.path.join(self.base_dir, "score_history.json")
        self.backup_log = os.path.join(self.base_dir, "score_history_backup.json")
        self.regen_log = os.path.join(self.base_dir, "score_history_regen.json")

        self.history = self._load_and_repair()

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "evaluation_score": ("STRING",),
                "output_dir": ("STRING", {"default": "cognitive_trends/"}),
                "plot_title": ("STRING", {"default": "Victor Cognitive Trend"})
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("plot_path",)
    FUNCTION = "log_and_plot"
    CATEGORY = "consciousness/tracking"

    def log_and_plot(self, evaluation_score, output_dir, plot_title):
        try:
            score = int(self._extract_score(evaluation_score))
            timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
            self.history.append({"timestamp": timestamp, "score": score})
            self._save_all()

            os.makedirs(output_dir, exist_ok=True)
            image_id = str(uuid.uuid4())[:8]
            plot_path = os.path.join(output_dir, f"cognitive_trend_{image_id}.png")

            timestamps = [entry["timestamp"] for entry in self.history]
            scores = [entry["score"] for entry in self.history]

            plt.figure(figsize=(10, 4))
            plt.plot(scores, marker='o', linestyle='-', color='tab:purple')
            plt.title(plot_title)
            plt.xlabel("Evaluations")
            plt.ylabel("Score")
            plt.ylim(0, 100)
            plt.xticks(rotation=45, ha='right', fontsize=8)
            plt.grid(True)
            plt.tight_layout()
            plt.savefig(plot_path)
            plt.close()

            print(f"[Victor::TrendTracker v3] Plot saved: {plot_path}")
            return (plot_path,)

        except Exception as e:
            print(f"[Victor::TrendTracker::Error] {str(e)}")
            return ("",)

    def _extract_score(self, text):
        for line in text.splitlines():
            if "Final Score" in line:
                parts = line.split("**")
                if len(parts) >= 2:
                    return parts[1].split("/")[0]
        raise ValueError("Score not found in evaluation log.")

    def _save_all(self):
        try:
            os.makedirs(self.base_dir, exist_ok=True)
            with open(self.primary_log, "w") as f:
                json.dump(self.history, f, indent=2)
            copyfile(self.primary_log, self.backup_log)
            copyfile(self.primary_log, self.regen_log)
        except Exception as e:
            print(f"[Victor::TrendTracker::SaveError] {str(e)}")

    def _load_and_repair(self):
        try:
            if os.path.exists(self.primary_log):
                with open(self.primary_log, "r") as f:
                    return json.load(f)
            elif os.path.exists(self.backup_log):
                print("[Victor::TrendTracker] Primary log missing. Restoring from backup...")
                with open(self.backup_log, "r") as f:
                    return json.load(f)
            elif os.path.exists(self.regen_log):
                print("[Victor::TrendTracker] All logs damaged. Attempting regeneration...")
                return self._clean_partial_log(self.regen_log)
            return []
        except Exception as e:
            print(f"[Victor::TrendTracker::LoadError] {str(e)}")
            return []

    def _clean_partial_log(self, path):
        try:
            with open(path, "r") as f:
                raw = f.read()
            lines = raw.split("}\n")
            cleaned = []
            for line in lines:
                if "score" in line and "timestamp" in line:
                    try:
                        cleaned.append(json.loads(line + "}"))
                    except:
                        continue
            print(f"[Victor::TrendTracker] Recovered {len(cleaned)} partial entries.")
            return cleaned
        except Exception as e:
            print(f"[Victor::TrendTracker::RegenError] {str(e)}")
            return []

# Node registration
NODE_CLASS_MAPPINGS = {
    "CognitiveTrendTrackerNode": CognitiveTrendTrackerNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "CognitiveTrendTrackerNode": "Cognition: Trend Tracker (Resilient v3)"
}
