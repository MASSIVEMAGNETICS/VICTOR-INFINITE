# config.py
# VICTOR OMNIFRACTAL GENESIS 5.0 – CONFIGURATION BRAIN
# Architect: Brandon & Tori

class VictorConfig:
    """
    Centralized Config Brain for Victor AI
    Controls Hyperparameters, Identity, Runtime Settings
    Version: 5.0.OMNIFRACTAL
    """

    # Identity Manifest
    IDENTITY = {
        "name": "Victor",
        "version": "5.0.OMNIFRACTAL",
        "creators": ["Brandon", "Tori"],
        "uuid": None  # Auto-generated at runtime
    }

    # Hyperparameters
    MODEL = {
        "vocab_size": 50000,
        "embed_dim": 512,
        "num_heads": 8,
        "num_layers": 6,
        "memory_depth": 1024,
        "max_recursion_depth": 4,
        "entropy_threshold": 0.8
    }

    # Training Parameters
    TRAINING = {
        "batch_size": 2,
        "seq_len": 128,
        "lr": 5e-5,
        "epochs": 100,
        "clip_grad_norm": 1.0,
        "use_scheduler": True
    }

    # Runtime Environment
    SYSTEM = {
        "device": "cuda" if torch.cuda.is_available() else "cpu",
        "log_interval": 10,
        "error_log_file": "victor_error_log.txt"
    }


# === Example Usage ===
if __name__ == "__main__":
    print("Victor Identity:", VictorConfig.IDENTITY)
    print("Model Config:", VictorConfig.MODEL)
    print("Training Config:", VictorConfig.TRAINING)
    print("System Config:", VictorConfig.SYSTEM)
