# File: comfyui_wrappers/fractal_thought_to_audio_node.py
# Description: God-tier resilient TTS node converting thoughts to emotionally reactive speech

from typing import Tuple
import pyttsx3
import tempfile
import os
import traceback

class FractalThoughtToAudioNode:
    VERSION = "v1.1.0 – GOD-TIER THOUGHT VOICE"
    CATEGORY = "Fractal/Audio"
    FUNCTION = "thought_to_audio"

    def __init__(self):
        try:
            self.engine = pyttsx3.init()
            self.voices = self.engine.getProperty('voices')
        except Exception as e:
            raise RuntimeError(f"TTS Engine initialization failed: {str(e)}")

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "thought_text": ("STRING", {}),
                "emotion": ("STRING", {"default": "neutral"}),
                "voice_gender": ("STRING", {"default": "female", "options": ["male", "female"]}),
                "rate": ("INT", {"default": 160, "min": 80, "max": 300})
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("audio_path",)

    def thought_to_audio(self, thought_text: str, emotion: str, voice_gender: str, rate: int) -> Tuple[str]:
        try:
            if not isinstance(thought_text, str) or not thought_text.strip():
                raise ValueError("Thought text must be a non-empty string.")

            voice = next((v for v in self.voices if voice_gender.lower() in v.name.lower()), None)
            if voice:
                self.engine.setProperty('voice', voice.id)
            else:
                raise ValueError(f"Requested voice gender '{voice_gender}' not available on this system.")

            self.engine.setProperty('rate', rate)

            emotion_prefix = f"({emotion.upper()}) " if emotion.lower() != "neutral" else ""
            final_text = emotion_prefix + thought_text.strip()

            with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as tf:
                filename = tf.name

            self.engine.save_to_file(final_text, filename)
            self.engine.runAndWait()

            if not os.path.exists(filename) or os.path.getsize(filename) < 128:
                raise IOError("TTS output file is missing or too small to be valid.")

            return (filename,)

        except Exception as e:
            fallback_path = os.path.join(tempfile.gettempdir(), "thought_audio_fallback.txt")
            fallback_msg = f"[ERROR] Thought-to-Audio failed: {str(e)}\n{traceback.format_exc()}"
            with open(fallback_path, "w") as f:
                f.write(fallback_msg)
            return (fallback_path,)


NODE_CLASS_MAPPINGS = {
    "FractalThoughtToAudioNode": FractalThoughtToAudioNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "FractalThoughtToAudioNode": "🗣️ FractalThoughtToAudio (God-Tier)"
}
