# File: fractal_intent_interpreter_node.py
# Location: ComfyUI/custom_nodes/victor_nodes/fractal/
# Version: 0.1.0 - INTENT-SEER ALPHA
# Description: Analyzes token stream metadata to infer dominant intent, mood profile, and semantic drift patterns.

from typing import List, Dict, Tuple
from datetime import datetime

class FractalIntentInterpreterNode:
    """
    Node: FractalIntentInterpreterNode
    Purpose: Interprets intent and mood bias from fractal tokens.

    Inputs:
        - tokens (List[dict]): List of token dicts from FractalTokenizerNode
        - strategy (str): Analysis strategy ['dominant', 'drift-map', 'average']

    Outputs:
        - inferred_intent (str): Most likely intent tag
        - mood_profile (dict): Normalized mood vector analysis
        - intent_weights (dict): Mapping of intent tag -> influence score

    Version: 0.1.0 - INTENT-SEER ALPHA
    """

    VERSION = "0.1.0 - INTENT-SEER ALPHA"
    CATEGORY = "Victor/Language"
    FUNCTION = "analyze_intent"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "tokens": ("LIST", {}),
                "strategy": ("STRING", {"default": "dominant"})
            }
        }

    RETURN_TYPES = ("STRING", "DICT", "DICT")
    RETURN_NAMES = ("inferred_intent", "mood_profile", "intent_weights")

    def analyze_vector(self, tokens: List[Dict]) -> Dict[str, float]:
        """Aggregate and normalize mood vector."""
        aggregate = []
        for t in tokens:
            mv = t.get("metadata", {}).get("mood_influence")
            if isinstance(mv, list):
                if not aggregate:
                    aggregate = [0.0] * len(mv)
                for i in range(len(mv)):
                    aggregate[i] += mv[i]

        if not aggregate:
            return {}
        total = sum(aggregate)
        return {f"dim_{i}": round(val / total, 3) for i, val in enumerate(aggregate)} if total != 0 else {}

    def analyze_intents(self, tokens: List[Dict]) -> Dict[str, float]:
        """Count and weight intents from token metadata."""
        intent_counter = {}
        for t in tokens:
            intents = t.get("metadata", {}).get("intent_influence")
            if isinstance(intents, list):
                for tag in intents:
                    intent_counter[tag] = intent_counter.get(tag, 0) + 1
        total = sum(intent_counter.values())
        return {k: round(v / total, 3) for k, v in intent_counter.items()} if total > 0 else {}

    def infer_dominant_intent(self, intent_weights: Dict[str, float]) -> str:
        if not intent_weights:
            return "unknown"
        return max(intent_weights.items(), key=lambda x: x[1])[0]

    def analyze_drift(self, tokens: List[Dict]) -> Dict[str, float]:
        """Optional drift-map stub. Could analyze shift over time."""
        # Placeholder - in future can add weighted window scanning
        return self.analyze_intents(tokens)

    def analyze_intent(self, tokens: List[Dict], strategy: str = "dominant") -> Tuple[str, Dict, Dict]:
        mood_profile = self.analyze_vector(tokens)
        intent_weights = self.analyze_intents(tokens)

        if strategy == "drift-map":
            intent_weights = self.analyze_drift(tokens)
        elif strategy == "average":
            pass  # same as default for now

        inferred_intent = self.infer_dominant_intent(intent_weights)
        return inferred_intent, mood_profile, intent_weights
