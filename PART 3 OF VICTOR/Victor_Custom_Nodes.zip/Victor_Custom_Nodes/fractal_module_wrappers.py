# File: comfyui_wrappers/fractal_module_wrappers.py
# Description: Wrappers to integrate FractalTokenizer, FractalTransformer, and generate_response into ComfyUI nodes.

from typing import List, Tuple
import torch
from Fractal_Tokenizer import FractalTokenizer
from generate_response import generate_response
from fractal_chatbot import model as pretrained_model

class FractalTokenizerNode:
    VERSION = "v1.0.0-COMFY"
    CATEGORY = "Fractal/Language"
    FUNCTION = "encode"

    def __init__(self):
        self.tokenizer = FractalTokenizer(min_freq=1, max_depth=2)
        # Pre-build minimal vocab (or expect user to build externally)
        self.tokenizer.build_vocab("hello fractal recursion transformation silence language emotions")

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "text": ("STRING", {"default": "hello fractal transformer"})
            }
        }

    RETURN_TYPES = ("LIST",)
    RETURN_NAMES = ("tokens",)

    def encode(self, text: str) -> Tuple[List[int]]:
        return (self.tokenizer.encode(text),)


class FractalDecoderNode:
    VERSION = "v1.0.0-COMFY"
    CATEGORY = "Fractal/Language"
    FUNCTION = "decode"

    def __init__(self):
        self.tokenizer = FractalTokenizer(min_freq=1, max_depth=2)
        self.tokenizer.build_vocab("hello fractal recursion transformation silence language emotions")

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "tokens": ("LIST", {})
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("decoded_text",)

    def decode(self, tokens: List[int]) -> Tuple[str]:
        return (self.tokenizer.decode(tokens),)


class FractalResponseNode:
    VERSION = "v1.0.0-COMFY"
    CATEGORY = "Fractal/Chat"
    FUNCTION = "respond"

    def __init__(self):
        self.model = pretrained_model

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "input_text": ("STRING", {"default": "What is the meaning of life?"}),
                "max_length": ("INT", {"default": 20, "min": 1, "max": 100})
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("response",)

    def respond(self, input_text: str, max_length: int) -> Tuple[str]:
        return (generate_response(input_text, max_length),)


# Node registration mappings
NODE_CLASS_MAPPINGS = {
    "FractalTokenizerNode": FractalTokenizerNode,
    "FractalDecoderNode": FractalDecoderNode,
    "FractalResponseNode": FractalResponseNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "FractalTokenizerNode": "🧬 Fractal Tokenizer",
    "FractalDecoderNode": "🔁 Fractal Decoder",
    "FractalResponseNode": "💬 Fractal Response Generator"
}
