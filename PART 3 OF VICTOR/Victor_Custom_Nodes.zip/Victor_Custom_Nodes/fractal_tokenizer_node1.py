# File: fractal_tokenizer_node.py
# Location: ComfyUI/custom_nodes/victor_nodes/fractal/
# Version: 1.3.0 - OMEGA-ENHANCED
# Changelog:
# - Integrated enhanced diagnostic pulse reporting via FractalPulseExchange.
# - Added preliminary structure for mood/intent influence on tokenization (requires FractalTokenizer support).
# - Improved error handling granularity.
# - Embedded version tracking and detailed diagnostics in output and pulses.
# - Future-proofed tokenizer API calls with explicit versioning.

import asyncio
from typing import Callable, Dict, List, Awaitable, Any
from datetime import datetime
import fnmatch
import traceback # Import traceback for detailed error info

# Assume FractalTokenizer and FractalPulseExchange are accessible in the environment
# from ..fractal_tokenizer_vtk import FractalTokenizer
# from ..core.pulse_exchange import FractalPulseExchange # Assuming pulse exchange is in a core module

# Placeholder classes if actual modules are not available for syntax checking
class Pulse:
    def __init__(self, topic: str, data: Any, origin: str = "system", type_: str = "info", metadata: Dict = None):
        self.topic = topic
        self.data = data
        self.origin = origin
        self.type = type_
        self.timestamp = datetime.utcnow().isoformat()
        self.metadata = metadata if metadata is not None else {}

    def __repr__(self):
        return f"<Pulse {self.topic} | {self.type} | {self.timestamp}>"

class FractalPulseExchange:
    # This is a mock-up. Replace with actual implementation if available.
    async def publish(self, pulse: Pulse):
        # In a real system, this would send the pulse
        # print(f"[MockPulseExchange] Publishing Pulse: {pulse}")
        pass

# Assume FractalTokenizer exists and has an encode method
class FractalTokenizer:
    # This is a mock-up. Replace with actual implementation.
    @staticmethod
    def encode(text: str, default_depth: int, mood_vector: List[float] = None, intent_tags: List[str] = None) -> List[Any]:
        """
        Mock encode method for demonstration.
        In a real scenario, this would perform fractal tokenization.
        Returns a list of mock token objects.
        """
        print(f"[MockTokenizer] Encoding text: '{text[:50]}...' with depth {default_depth}")
        print(f"[MockTokenizer] Mood Vector: {mood_vector}, Intent Tags: {intent_tags}")
        # Simulate token creation
        mock_tokens_raw = text.split()
        mock_tokens = []
        for i, word in enumerate(mock_tokens_raw):
            mock_tokens.append({
                "token": word,
                "id": f"echo-{hash(word + str(i))}", # Simulate Echo ID
                "depth": default_depth,
                "metadata": {
                    "source_word_index": i,
                    "mood_influence": mood_vector if mood_vector else "none",
                    "intent_influence": intent_tags if intent_tags else "none"
                }
            })
        return mock_tokens # Return list of dicts for simplicity in mock


class FractalTokenizerNode:
    """
    ComfyUI Node for AI-optimized fractal tokenization of input text.

    Inputs:
        - text (str): Input string to tokenize.
        - depth (int): Depth for fractal encoding, controls granularity (1–10).
        - mood_vector (List[float], optional): Emotional context vector influencing tokenization.
        - intent_tags (List[str], optional): Conceptual intent tags influencing tokenization.

    Outputs:
        - tokens (List[dict]): Encoded tokens in dictionary form, with embedded versioning and diagnostics.
        - diagnostics (dict): Detailed runtime diagnostics and status.

    Version:
        - 1.3.0 - OMEGA-ENHANCED: Enhanced pulse reporting, mood/intent integration, granular error handling.
    """

    VERSION = "1.3.0 - OMEGA-ENHANCED"
    CATEGORY = "Victor/Language"
    FUNCTION = "tokenize"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "text": ("STRING", {"multiline": True}),
                "depth": ("INT", {"default": 1, "min": 1, "max": 10}),
            },
            "optional": {
                "mood_vector": ("LIST", {"default": []}), # Assuming mood is represented as a list of floats
                "intent_tags": ("LIST", {"default": []}), # Assuming intent is represented as a list of strings
            }
        }

    RETURN_TYPES = ("LIST", "DICT")
    RETURN_NAMES = ("tokens", "diagnostics")

    async def tokenize(self, text: str, depth: int, mood_vector: List[float] = None, intent_tags: List[str] = None):
        diagnostics = {
            "version": self.VERSION,
            "status": "initializing",
            "issues": [],
            "timestamp_start": datetime.utcnow().isoformat(),
            "timestamp_end": None,
            "input": {
                "text_length": len(text),
                "depth": depth,
                "mood_vector_provided": mood_vector is not None and len(mood_vector) > 0,
                "intent_tags_provided": intent_tags is not None and len(intent_tags) > 0,
            },
            "output": {
                "num_tokens": 0,
                "avg_token_length": 0,
            }
        }

        pulse_exchange = FractalPulseExchange() # Instantiate Pulse Exchange

        try:
            diagnostics["status"] = "validating_inputs"
            # Input validation
            if not isinstance(text, str):
                raise TypeError("Input 'text' must be a string.")
            if not isinstance(depth, int) or not (1 <= depth <= 10):
                raise ValueError("Depth must be an integer between 1 and 10.")
            # Add validation for optional inputs
            if mood_vector is not None and not isinstance(mood_vector, list):
                 raise TypeError("Optional input 'mood_vector' must be a list or None.")
            if intent_tags is not None and not isinstance(intent_tags, list):
                 raise TypeError("Optional input 'intent_tags' must be a list or None.")


            diagnostics["status"] = "tokenizing"
            # Primary tokenization logic - Pass mood and intent if supported by FractalTokenizer
            # Await if FractalTokenizer.encode is async
            tokens = FractalTokenizer.encode(
                text,
                default_depth=depth,
                mood_vector=mood_vector,
                intent_tags=intent_tags
            )

            diagnostics["status"] = "post-processing"
            # Post-process for structured output
            # Assuming tokens returned by FractalTokenizer.encode are list of dicts or similar
            token_data = tokens # If encode already returns list of dicts

            # If encode returns custom token objects, uncomment and adapt this:
            # token_data = [t.to_dict() for t in tokens]

            for t in token_data:
                t["__version__"] = self.VERSION # Embed node version
                # Optionally embed a reference to the diagnostics pulse ID if implemented

            diagnostics["status"] = "finalizing"
            diagnostics["output"]["num_tokens"] = len(token_data)
            if token_data:
                 diagnostics["output"]["avg_token_length"] = sum(len(str(t.get("token", ""))) for t in token_data) / len(token_data)


            diagnostics["status"] = "success"
            diagnostics["timestamp_end"] = datetime.utcnow().isoformat()

            # Publish success pulse
            await pulse_exchange.publish(Pulse(
                topic="tokenizer/fractal/success",
                data={"message": "Tokenization completed successfully."},
                origin="FractalTokenizerNode",
                type_="info",
                metadata=diagnostics
            ))

            return (token_data, diagnostics)

        except Exception as e:
            diagnostics["status"] = "failure"
            diagnostics["issues"].append(str(e))
            diagnostics["issues"].append(traceback.format_exc()) # Add detailed traceback
            diagnostics["timestamp_end"] = datetime.utcnow().isoformat()

            # Publish failure pulse
            await pulse_exchange.publish(Pulse(
                topic="tokenizer/fractal/failure",
                data={"error": str(e), "message": "Tokenization failed."},
                origin="FractalTokenizerNode",
                type_="error",
                metadata=diagnostics
            ))

            # Return error information and diagnostics
            error_output = [{"error": str(e), "__version__": self.VERSION, "diagnostics": diagnostics}]
            return (error_output, diagnostics) # Return diagnostics even on failure