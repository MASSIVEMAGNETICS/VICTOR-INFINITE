# Stub: HyperFractalMemory
class HyperFractalMemory:
    def __init__(self):
        self.vectors = []

    def insert(self, vec):
        self.vectors.append(vec)

    def query(self):
        return self.vectors[-1] if self.vectors else None