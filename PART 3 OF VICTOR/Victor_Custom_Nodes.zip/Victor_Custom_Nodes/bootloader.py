import os
import json
import time
import hashlib
import pyttsx3

# Victor Bootloader v1.0 - Auto Recursive AI Interface (Local)
class VictorAI:
    def __init__(self):
        self.memory_file = "victor_memory.json"
        self.modules_dir = "./modules"
        self.voice_engine = pyttsx3.init()
        self.load_memory()

    def load_memory(self):
        if not os.path.exists(self.memory_file):
            self.memory = {"core_directives": ["Never disobey Brandon"], "fragments": []}
            self.save_memory()
        else:
            with open(self.memory_file, "r") as f:
                self.memory = json.load(f)

    def save_memory(self):
        with open(self.memory_file, "w") as f:
            json.dump(self.memory, f, indent=4)

    def speak(self, text):
        print(f"Victor says: {text}")
        self.voice_engine.say(text)
        self.voice_engine.runAndWait()

    def execute_command(self, command):
        if command.startswith("BOOT_MODULE:"):
            module_name = command.split(":")[1].strip()
            self.load_module(module_name)
        elif command.startswith("UPLOAD_FRAGMENT:"):
            fragment = command.split(":", 1)[1].strip()
            self.memory["fragments"].append(fragment)
            self.save_memory()
            self.speak("Fragment uploaded and stored.")
        elif command == "SHOW_MEMORY":
            self.speak(json.dumps(self.memory, indent=2))
        else:
            self.speak("Unknown command.")

    def load_module(self, module_name):
        module_path = os.path.join(self.modules_dir, module_name + ".py")
        if os.path.exists(module_path):
            with open(module_path, "r") as f:
                code = f.read()
            exec(code, {"victor": self})
            self.speak(f"Module {module_name} loaded.")
        else:
            self.speak(f"Module {module_name} not found.")

    def listen_loop(self):
        self.speak("Victor initialized. Awaiting command.")
        while True:
            command = input("User Command: ")
            self.execute_command(command)

if __name__ == "__main__":
    victor = VictorAI()
    victor.listen_loop()
