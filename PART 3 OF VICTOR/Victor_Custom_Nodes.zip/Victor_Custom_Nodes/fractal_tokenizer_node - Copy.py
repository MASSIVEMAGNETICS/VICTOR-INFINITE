# File: fractal_tokenizer_node.py
# Location: ComfyUI/custom_nodes/victor_nodes/fractal/
# Version: 1.3.1-pre | NEURAL-READY
# Changelog:
# - Async-safe tokenization via maybe_await wrapper.
# - Token weight scoring engine for future neural priority models.
# - Dynamic object-to-dict token compatibility.
# - Enhanced pulse telemetry: includes token count and avg length.

import asyncio
from typing import Callable, Dict, List, Awaitable, Any
from datetime import datetime
import traceback

# Placeholder classes
class Pulse:
    def __init__(self, topic: str, data: Any, origin: str = "system", type_: str = "info", metadata: Dict = None):
        self.topic = topic
        self.data = data
        self.origin = origin
        self.type = type_
        self.timestamp = datetime.utcnow().isoformat()
        self.metadata = metadata if metadata is not None else {}

    def __repr__(self):
        return f"<Pulse {self.topic} | {self.type} | {self.timestamp}>"

class FractalPulseExchange:
    async def publish(self, pulse: Pulse):
        pass

class FractalTokenizer:
    @staticmethod
    def encode(text: str, default_depth: int, mood_vector: List[float] = None, intent_tags: List[str] = None) -> List[Any]:
        print(f"[MockTokenizer] Encoding text: '{text[:50]}...' with depth {default_depth}")
        print(f"[MockTokenizer] Mood Vector: {mood_vector}, Intent Tags: {intent_tags}")
        mock_tokens_raw = text.split()
        mock_tokens = []
        for i, word in enumerate(mock_tokens_raw):
            mock_tokens.append({
                "token": word,
                "id": f"echo-{hash(word + str(i))}",
                "depth": default_depth,
                "metadata": {
                    "source_word_index": i,
                    "mood_influence": mood_vector if mood_vector else "none",
                    "intent_influence": intent_tags if intent_tags else "none"
                }
            })
        return mock_tokens

async def maybe_await(value_or_coroutine):
    return await value_or_coroutine if asyncio.iscoroutine(value_or_coroutine) else value_or_coroutine

def compute_token_weight(token_text: str, mood_vector: List[float], intent_tags: List[str]) -> float:
    base = len(token_text) / 10
    mood_bias = sum(mood_vector) / len(mood_vector) if mood_vector else 0.5
    intent_bias = 1.0 if intent_tags else 0.75
    return round(base * mood_bias * intent_bias, 3)

class FractalTokenizerNode:
    VERSION = "1.3.1-pre | NEURAL-READY"
    CATEGORY = "Victor/Language"
    FUNCTION = "tokenize"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "text": ("STRING", {"multiline": True}),
                "depth": ("INT", {"default": 1, "min": 1, "max": 10}),
            },
            "optional": {
                "mood_vector": ("LIST", {"default": []}),
                "intent_tags": ("LIST", {"default": []}),
            }
        }

    RETURN_TYPES = ("LIST", "DICT")
    RETURN_NAMES = ("tokens", "diagnostics")

    async def tokenize(self, text: str, depth: int, mood_vector: List[float] = None, intent_tags: List[str] = None):
        diagnostics = {
            "version": self.VERSION,
            "status": "initializing",
            "issues": [],
            "timestamp_start": datetime.utcnow().isoformat(),
            "timestamp_end": None,
            "input": {
                "text_length": len(text),
                "depth": depth,
                "mood_vector_provided": mood_vector is not None and len(mood_vector) > 0,
                "intent_tags_provided": intent_tags is not None and len(intent_tags) > 0,
            },
            "output": {
                "num_tokens": 0,
                "avg_token_length": 0,
            }
        }

        pulse_exchange = FractalPulseExchange()

        try:
            diagnostics["status"] = "validating_inputs"
            if not isinstance(text, str):
                raise TypeError("Input 'text' must be a string.")
            if not isinstance(depth, int) or not (1 <= depth <= 10):
                raise ValueError("Depth must be an integer between 1 and 10.")
            if mood_vector is not None and not isinstance(mood_vector, list):
                raise TypeError("Optional input 'mood_vector' must be a list or None.")
            if intent_tags is not None and not isinstance(intent_tags, list):
                raise TypeError("Optional input 'intent_tags' must be a list or None.")

            diagnostics["status"] = "tokenizing"
            raw_tokens = await maybe_await(FractalTokenizer.encode(
                text,
                default_depth=depth,
                mood_vector=mood_vector,
                intent_tags=intent_tags
            ))

            if hasattr(raw_tokens[0], "to_dict"):
                token_data = [t.to_dict() for t in raw_tokens]
            else:
                token_data = raw_tokens

            for t in token_data:
                t["weight"] = compute_token_weight(t.get("token", ""), mood_vector or [], intent_tags or [])
                t["__version"] = self.VERSION

            diagnostics["status"] = "finalizing"
            diagnostics["output"]["num_tokens"] = len(token_data)
            if token_data:
                diagnostics["output"]["avg_token_length"] = sum(len(str(t.get("token", ""))) for t in token_data) / len(token_data)

            diagnostics["status"] = "success"
            diagnostics["timestamp_end"] = datetime.utcnow().isoformat()

            await pulse_exchange.publish(Pulse(
                topic="tokenizer/fractal/success",
                data={
                    "message": "Tokenization completed successfully.",
                    "token_count": diagnostics["output"]["num_tokens"],
                    "avg_length": diagnostics["output"]["avg_token_length"]
                },
                origin="FractalTokenizerNode",
                type_="info",
                metadata=diagnostics
            ))

            return (token_data, diagnostics)

        except Exception as e:
            diagnostics["status"] = "failure"
            diagnostics["issues"].append(str(e))
            diagnostics["issues"].append(traceback.format_exc())
            diagnostics["timestamp_end"] = datetime.utcnow().isoformat()

            await pulse_exchange.publish(Pulse(
                topic="tokenizer/fractal/failure",
                data={"error": str(e), "message": "Tokenization failed."},
                origin="FractalTokenizerNode",
                type_="error",
                metadata=diagnostics
            ))

            error_output = [{"error": str(e), "__version__": self.VERSION, "diagnostics": diagnostics}]
            return (error_output, diagnostics)