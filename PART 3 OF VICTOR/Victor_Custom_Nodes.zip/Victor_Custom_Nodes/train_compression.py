# File: train_compression.py
# Version: v1.0.0-GOD-TIER-FRACTALIZED
# Description: Core training script with fractal compression hooks, checkpointing, and low-spec compatibility

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
import os
import hashlib
import time

from bando_transformer import BandoTransformer
from fractal_compression import FractalHook

class DummyDataset(Dataset):
    def __init__(self, size=10000, seq_len=32, vocab_size=1000):
        self.data = torch.randint(0, vocab_size, (size, seq_len))

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        x = self.data[idx][:-1]
        y = self.data[idx][1:]
        return x, y

def save_model(model, path):
    torch.save(model.state_dict(), path)
    print(f"✅ Saved checkpoint to {path}")

def hash_checkpoint(model):
    hasher = hashlib.sha256()
    for param in model.parameters():
        hasher.update(param.detach().cpu().numpy().tobytes())
    return hasher.hexdigest()[:8]

def train(model, dataloader, optimizer, criterion, device):
    model.train()
    for epoch in range(3):  # You can expand this
        epoch_loss = 0.0
        for i, (x, y) in enumerate(dataloader):
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad()
            output = model(x)
            loss = criterion(output.view(-1, output.size(-1)), y.view(-1))
            loss.backward()
            optimizer.step()

            epoch_loss += loss.item()
            if i % 100 == 0:
                print(f"[Epoch {epoch} | Step {i}] Loss: {loss.item():.4f}")
        print(f"🔥 Epoch {epoch} finished. Avg loss: {epoch_loss/len(dataloader):.4f}")

        # Save checkpoint
        ckpt_hash = hash_checkpoint(model)
        save_path = f"checkpoints/bando_transformer_{ckpt_hash}.pt"
        save_model(model, save_path)

if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"🚀 Using device: {device}")

    model = BandoTransformer()
    model.to(device)

    # 🔥 Optional Fractal Compression Hook
    FractalHook.inject(model)

    dataset = DummyDataset()
    dataloader = DataLoader(dataset, batch_size=32, shuffle=True)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.0003)

    os.makedirs("checkpoints", exist_ok=True)
    train(model, dataloader, optimizer, criterion, device)
