# Stub: Bark TTS Synthesizer
def bark_synthesize(text, voice_embed):
    print(f"[BARK_TTS_STUB] Synthesizing: {text} with voice {voice_embed}")
    return b"FAKE_AUDIO_BYTES"