# File: comfyui_wrappers/tts_thought_voice_node.py
# Description: Text-to-Speech node for reading recursive thoughts from FractalNeuroCoreNode aloud

from typing import Tuple
import pyttsx3
import tempfile
import os

class TTSThoughtVoiceNode:
    VERSION = "v1.0.0 – THOUGHT-VOICE"
    CATEGORY = "Fractal/Audio"
    FUNCTION = "speak_thought"

    def __init__(self):
        self.engine = pyttsx3.init()
        self.engine.setProperty('rate', 160)  # Optional: slower rate for introspection

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "thought_text": ("STRING", {})
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("audio_file_path",)

    def speak_thought(self, thought_text: str) -> Tuple[str]:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as tf:
            filename = tf.name
        self.engine.save_to_file(thought_text, filename)
        self.engine.runAndWait()
        return (filename,)


NODE_CLASS_MAPPINGS = {
    "TTSThoughtVoiceNode": TTSThoughtVoiceNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "TTSThoughtVoiceNode": "🗣️ ThoughtVoiceTTS"
}
