# File: comfyui_wrappers/fractalformer_fusion_node.py
# Description: Multi-modal FractalFormer with 8 inputs fused into semantic vector, thought, and generative text output.

from typing import List, Tuple, Dict
import torch
from generate_response import generate_response
from Fractal_Tokenizer import FractalTokenizer

class FractalFormerFusionNode:
    VERSION = "v1.0.0 – MULTI-FUSION"
    CATEGORY = "Fractal/Advanced"
    FUNCTION = "fuse_and_generate"

    def __init__(self):
        self.tokenizer = FractalTokenizer(min_freq=1, max_depth=2)
        self.tokenizer.build_vocab("emotions fusion cognition response token semantic vectorized synthetic stream")

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "text_input": ("STRING", {}),
                "mood_vector": ("LIST", {}),
                "intent_tags": ("LIST", {}),
                "feeling_state": ("STRING", {}),
                "memory_trace": ("STRING", {}),
                "context_notes": ("STRING", {}),
                "user_profile": ("STRING", {}),
                "environmental_prompt": ("STRING", {})
            }
        }

    RETURN_TYPES = ("STRING", "LIST", "STRING", "STRING")
    RETURN_NAMES = ("semantic_label", "vector_output", "thought_output", "text_output")

    def fuse_and_generate(
        self,
        text_input: str,
        mood_vector: List[float],
        intent_tags: List[str],
        feeling_state: str,
        memory_trace: str,
        context_notes: str,
        user_profile: str,
        environmental_prompt: str
    ) -> Tuple[str, List[float], str, str]:

        # Semantic vector fusion (placeholder average with modifiers)
        base_vec = torch.tensor(mood_vector if mood_vector else [0.5, 0.5, 0.5])
        mod_scalar = len(intent_tags) + (1 if "reflect" in intent_tags else 0)
        fused_vector = torch.tanh(base_vec * mod_scalar).tolist()

        # Thought synthesis
        semantic_label = f"Semantic-{intent_tags[0] if intent_tags else 'undefined'}"
        thought_output = f"While reflecting on '{text_input}', within the context of {context_notes}, the emotional tone of {feeling_state} steers the intent {intent_tags}."

        # Prompt conditioning for generation
        fused_prompt = f"User:{user_profile}\nEnvironment:{environmental_prompt}\nMemory:{memory_trace}\nContext:{context_notes}\nMood:{mood_vector}\nIntent:{intent_tags}\nFeeling:{feeling_state}\n---\n{text_input}"
        text_output = generate_response(fused_prompt, max_length=40)

        return semantic_label, fused_vector, thought_output, text_output


NODE_CLASS_MAPPINGS = {
    "FractalFormerFusionNode": FractalFormerFusionNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "FractalFormerFusionNode": "🧬 FractalFormerFusion"
}
