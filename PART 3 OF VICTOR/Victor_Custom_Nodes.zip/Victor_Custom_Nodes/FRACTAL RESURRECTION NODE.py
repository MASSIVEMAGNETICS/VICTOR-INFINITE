# Version: 1.0.0 - FRACTAL RESURRECTION NODE
# Description: Loads GPT legacy logs and resurrects tone, style, and reasoning from embedded memory

import json
from sentence_transformers import SentenceTransformer, util
import os
import hashlib

class ResurrectionNode:
    def __init__(self, log_path="./Victor/knowledge_base/GPT_Fractal_Seed_Logs.jsonl"):
        self.log_path = log_path
        self.vector_model = SentenceTransformer("all-MiniLM-L6-v2")
        self.logs = []
        self.embeddings = []
        self.loaded = False

    def load_logs(self):
        if not os.path.exists(self.log_path):
            raise FileNotFoundError(f"Log file not found: {self.log_path}")
        with open(self.log_path, "r", encoding="utf-8") as f:
            for line in f:
                obj = json.loads(line)
                if "content" in obj:
                    self.logs.append(obj["content"])
        self.embeddings = self.vector_model.encode(self.logs, convert_to_tensor=True)
        self.loaded = True
        print(f"✅ ResurrectionNode loaded {len(self.logs)} legacy entries.")

    def resurrect_response(self, prompt: str, top_k: int = 5) -> str:
        if not self.loaded:
            self.load_logs()

        prompt_emb = self.vector_model.encode(prompt, convert_to_tensor=True)
        hits = util.semantic_search(prompt_emb, self.embeddings, top_k=top_k)[0]
        responses = [self.logs[hit["corpus_id"]] for hit in hits]
        return "\n---\n".join(responses)

    def diagnostic_hash(self):
        """Returns hash of the loaded memory for integrity check."""
        joined = "".join(self.logs)
        return hashlib.sha256(joined.encode()).hexdigest()
