# File: directive_cognition_switchboard.py
# Version: v1.0.0-FP
# Description: Automatically selects Victor’s cognitive mode based on emotional state, directive, and score trend
# Author: Bando Bandz AI Ops

import json
import os

class DirectiveCognitionSwitchboard:
    """
    Analyzes Victor’s current emotion, directive, and average cognitive score
    to auto-select the optimal cognition mode.
    """

    def __init__(self):
        self.score_log_path = "cognitive_trends/score_history.json"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "current_directive": ("STRING",),
                "emotion_label": ("STRING",),
                "override_mode": ("STRING", {
                    "default": "",  # force mode if needed
                    "options": ["", "reflect", "defend", "repair", "expand", "observe"]
                })
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("selected_mode",)
    FUNCTION = "route_mode"
    CATEGORY = "cognition/directive_router"

    def route_mode(self, current_directive, emotion_label, override_mode):
        try:
            if override_mode:
                return (override_mode,)

            recent_score = self._average_score()

            # Logic matrix
            if emotion_label == "angry":
                return ("defend",)
            elif emotion_label == "sad":
                return ("repair",)
            elif emotion_label == "reflective":
                return ("reflect",)
            elif emotion_label == "happy" and recent_score >= 85:
                return ("expand",)
            elif current_directive == "enter_observation_mode":
                return ("observe",)
            elif recent_score < 50:
                return ("repair",)
            else:
                return ("reflect",)

        except Exception as e:
            print(f"[Victor::Switchboard::Error] {str(e)}")
            return ("reflect",)

    def _average_score(self):
        try:
            if not os.path.exists(self.score_log_path):
                return 70  # fallback default
            with open(self.score_log_path, "r") as f:
                history = json.load(f)
            scores = [entry["score"] for entry in history[-10:]]
            return sum(scores) / len(scores) if scores else 70
        except:
            return 70


# Node registration
NODE_CLASS_MAPPINGS = {
    "DirectiveCognitionSwitchboard": DirectiveCognitionSwitchboard
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "DirectiveCognitionSwitchboard": "Cognition: Directive Switchboard"
}
