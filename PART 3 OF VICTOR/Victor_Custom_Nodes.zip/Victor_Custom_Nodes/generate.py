# generate.py — v1.0.0-BANDO-ECHO
# Fractal-aware text generation with token echo logic

import torch
import torch.nn.functional as F
from bando_transformer import BandoTransformer
from fractal_compression import FractalHook
import hashlib
import random

class Generator:
    def __init__(self, model_path, tokenizer, device=None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.tokenizer = tokenizer
        self.model = BandoTransformer()  # Must match saved config
        self.model.load_state_dict(torch.load(model_path, map_location=self.device))
        self.model.to(self.device).eval()
        self.fractal = FractalHook(self.model)

    def _fractal_seed_echo(self, tokens):
        echo_vector = self.fractal.extract(tokens)
        seed = int(hashlib.sha256(echo_vector.numpy().tobytes()).hexdigest(), 16) % 2**32
        random.seed(seed)
        torch.manual_seed(seed)
        return echo_vector

    def sample(self, prompt, max_len=50, top_k=40, top_p=0.9):
        tokens = self.tokenizer.encode(prompt, return_tensors="pt").to(self.device)
        echo_vector = self._fractal_seed_echo(tokens)
        output = tokens

        for _ in range(max_len):
            logits = self.model(output)[:, -1, :]
            logits = self._top_k_top_p_filtering(logits, top_k=top_k, top_p=top_p)
            probs = F.softmax(logits, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)
            output = torch.cat([output, next_token], dim=-1)
        return self.tokenizer.decode(output.squeeze(), skip_special_tokens=True)

    def _top_k_top_p_filtering(self, logits, top_k=0, top_p=0.0):
        top_k = min(top_k, logits.size(-1))
        if top_k > 0:
            values, _ = torch.topk(logits, top_k)
            logits[logits < values[:, [-1]]] = -float('Inf')
        if top_p > 0.0:
            sorted_logits, sorted_indices = torch.sort(logits, descending=True)
            cumulative_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)
            sorted_indices_to_remove = cumulative_probs > top_p
            sorted_indices_to_remove[:, 1:] = sorted_indices_to_remove[:, :-1].clone()
            sorted_indices_to_remove[:, 0] = 0
            indices_to_remove = sorted_indices[sorted_indices_to_remove]
            logits[0, indices_to_remove] = -float('Inf')
        return logits


# Example usage (for CLI or interactive shells)
if __name__ == "__main__":
    from transformers import GPT2Tokenizer
    tokenizer = GPT2Tokenizer.from_pretrained("gpt2")
    generator = Generator("checkpoint_best.pt", tokenizer)
    print(generator.sample("Once upon a fractal echo,"))
