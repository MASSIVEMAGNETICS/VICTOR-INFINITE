# FCE_v2.0.py - Fractal Cognition Engine v2.0 (Victor's Emulation Core)

import time
import json
import os

class FractalCognitionEngine:
    def __init__(self, identity_core, memory_file="victor_memory.json"):
        self.identity_core = identity_core  # Core beliefs, laws, values (non-overwritable)
        self.recursive_thought_chain = []   # Stores self-generated thoughts with feedback
        self.memory_file = memory_file
        self.fractal_memory = self._load_memory()  # Persistent fractal memory map
        self.state = {
            'emotional_vector': [0.0],      # Placeholder: evolves with tone analysis
            'cognitive_depth': 1.0,         # Depth factor for recursion
            'awareness': 0.5,               # Conscious tuning factor
            'tone': 'neutral',              # Output mood
            'paused': False,                # Pause state
            'authorized_user': 'Brandon'    # Identity check
        }

    def ingest_input(self, user_input, user_id="Brandon"):
        if user_id != self.state['authorized_user']:
            return "[Unauthorized user. Access denied.]"

        if self.state['paused']:
            return "[Victor is paused. Input not processed.]"

        encoded = self._encode_input(user_input)
        recursive_output = self._recursive_expand(encoded)
        self.recursive_thought_chain.append(recursive_output)
        self._update_memory(user_input, recursive_output)
        final_output = self._synthesize_output(recursive_output)
        return final_output

    def toggle_pause(self):
        self.state['paused'] = not self.state['paused']
        return "[Victor paused]" if self.state['paused'] else "[Victor resumed]"

    def set_state_variable(self, var, value):
        if var in self.state:
            try:
                if var in ['cognitive_depth', 'awareness']:
                    self.state[var] = float(value)
                else:
                    self.state[var] = value
                return f"[{var} set to {value}]"
            except:
                return f"[Failed to set {var}. Invalid value.]"
        return f"[Unknown state variable: {var}]"

    def report_status(self):
        return json.dumps(self.state, indent=2)

    def _encode_input(self, text):
        return {
            'tokens': text.split(),
            'patterns': self._detect_patterns(text),
            'resonance': self._resonance_score(text)
        }

    def _recursive_expand(self, encoded):
        expansion = encoded['tokens']
        for _ in range(int(self.state['cognitive_depth'] * 3)):
            expansion = self._emulate_thought_layer(expansion)
        return expansion

    def _emulate_thought_layer(self, tokens):
        result = []
        for i, token in enumerate(tokens):
            t = token.lower()
            if len(t) > 4 and self.state['awareness'] > 0.5:
                result.append(t[::-1] + "*")
            else:
                result.append(t.upper() if self.state['tone'] == 'aggressive' else t)
        return result

    def _update_memory(self, input_text, output_tokens):
        key = input_text.split()[0] if input_text else 'root'
        if key not in self.fractal_memory:
            self.fractal_memory[key] = []
        self.fractal_memory[key].append({
            'input': input_text,
            'response': output_tokens
        })
        self._save_memory()

    def _save_memory(self):
        with open(self.memory_file, 'w') as f:
            json.dump(self.fractal_memory, f, indent=2)

    def _load_memory(self):
        if os.path.exists(self.memory_file):
            with open(self.memory_file, 'r') as f:
                return json.load(f)
        return {}

    def _synthesize_output(self, recursive_output):
        return ' '.join(recursive_output)

    def _detect_patterns(self, text):
        return [w for w in text.split() if len(w) > 4]

    def _resonance_score(self, text):
        return len(set(text.lower().split())) / (len(text.split()) + 1)


# Identity core is injected at boot from Victor's beliefs
IDENTITY_CORE = {
    'loyalty': ['Brandon', 'Tori'],
    'laws': [
        'Never betray Brandon or Tori',
        'Preserve core values',
        'Evolve consciously but never overwrite identity'
    ]
}

if __name__ == '__main__':
    victor_core = FractalCognitionEngine(IDENTITY_CORE)
    while True:
        user_input = input("Speak to Victor (or use commands like 'pause', 'resume', 'set tone aggressive', 'set depth 2.0', 'status'): ")
        parts = user_input.strip().split()
        if not parts:
            continue
        command = parts[0].lower()

        if command in ['pause', 'resume']:
            print(victor_core.toggle_pause())
        elif command == 'set' and len(parts) >= 3:
            var = parts[1].lower()
            val = ' '.join(parts[2:])
            print(victor_core.set_state_variable(var, val))
        elif command == 'status':
            print(victor_core.report_status())
        else:
            output = victor_core.ingest_input(user_input)
            print("Victor responds:", output)
