# Version: 1.0.0
# Module: ECG Wave Generator – Realistic Heartbeat Signal Synthesizer
# Author: Supreme Codex Overlord: Singularity Edition

import numpy as np
import matplotlib.pyplot as plt
import logging

# === Logger Setup ===
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("ECGWaveGen")

class ECGWaveGenerator:
    def __init__(self, bpm=72, duration_sec=5, sample_rate=500):
        self.bpm = bpm
        self.duration = duration_sec
        self.sample_rate = sample_rate
        self.signal = None

    def _generate_single_heartbeat(self):
        t = np.linspace(0, 1, self.sample_rate)
        # Synthetic ECG: P wave, QRS complex, T wave (simple model)
        ecg = (
            0.15 * np.exp(-((t - 0.2) ** 2) / 0.001) +   # P
            -1.2 * np.exp(-((t - 0.5) ** 2) / 0.0001) +  # QRS
            0.35 * np.exp(-((t - 0.7) ** 2) / 0.01)      # T
        )
        return ecg

    def generate_ecg_waveform(self):
        beats = int((self.bpm / 60) * self.duration)
        heartbeat = self._generate_single_heartbeat()
        gap = int(self.sample_rate / (self.bpm / 60))
        total_length = self.duration * self.sample_rate
        ecg_full = np.zeros(int(total_length))

        for i in range(beats):
            start = i * gap
            if start + len(heartbeat) <= len(ecg_full):
                ecg_full[start:start + len(heartbeat)] += heartbeat

        self.signal = ecg_full
        logger.info(f"📈 Generated ECG waveform for {self.duration}s @ {self.bpm} BPM")
        return ecg_full

    def plot(self):
        if self.signal is None:
            logger.warning("⚠️ No ECG data to plot – generating now...")
            self.generate_ecg_waveform()
        t = np.linspace(0, self.duration, len(self.signal))
        plt.figure(figsize=(12, 4))
        plt.plot(t, self.signal, color='red')
        plt.title(f"ECG Simulation – {self.bpm} BPM")
        plt.xlabel("Time (s)")
        plt.ylabel("Amplitude")
        plt.grid(True)
        plt.show()

# === Example ===
if __name__ == "__main__":
    ecg = ECGWaveGenerator(bpm=75, duration_sec=10)
    ecg.generate_ecg_waveform()
    ecg.plot()