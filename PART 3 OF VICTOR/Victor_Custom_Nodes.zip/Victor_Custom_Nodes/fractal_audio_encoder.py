# File: fractal_audio_encoder.py
# Description: God-tier, self-healing, future-proof audio encoder for FractalWhisperCore

import torch
import torchaudio
import torchaudio.transforms as T
import os
import traceback

class FractalAudioEncoder:
    VERSION = "v1.0.0 – FRACTAL-AURAL-GOD-TIER"

    def __init__(self, sample_rate=16000, n_mels=80, win_length=400, hop_length=160, n_fft=512):
        self.sample_rate = sample_rate
        self.n_mels = n_mels
        self.transforms = T.MelSpectrogram(
            sample_rate=self.sample_rate,
            n_fft=n_fft,
            win_length=win_length,
            hop_length=hop_length,
            n_mels=self.n_mels,
            normalized=True
        )
        self.amplitude_to_db = T.AmplitudeToDB(stype="power", top_db=80)

    def load_audio(self, file_path: str) -> torch.Tensor:
        try:
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"Audio file not found: {file_path}")

            waveform, sr = torchaudio.load(file_path)
            if sr != self.sample_rate:
                resampler = T.Resample(orig_freq=sr, new_freq=self.sample_rate)
                waveform = resampler(waveform)

            if waveform.shape[0] > 1:
                waveform = torch.mean(waveform, dim=0, keepdim=True)  # convert to mono

            return waveform
        except Exception as e:
            error_trace = traceback.format_exc()
            print(f"[ERROR] load_audio failed: {str(e)}\n{error_trace}")
            return torch.zeros(1, self.sample_rate)  # 1 sec silence as fail-safe

    def encode(self, waveform: torch.Tensor) -> torch.Tensor:
        try:
            mel = self.transforms(waveform)
            mel_db = self.amplitude_to_db(mel)
            return mel_db
        except Exception as e:
            error_trace = traceback.format_exc()
            print(f"[ERROR] encode failed: {str(e)}\n{error_trace}")
            return torch.zeros(self.n_mels, 100)  # fallback shape

    def process_file(self, file_path: str) -> torch.Tensor:
        waveform = self.load_audio(file_path)
        mel_tensor = self.encode(waveform)
        return mel_tensor


# Example usage:
if __name__ == "__main__":
    encoder = FractalAudioEncoder()
    test_path = "./sample.wav"
    mel_output = encoder.process_file(test_path)
    print("Encoded Mel Shape:", mel_output.shape)
