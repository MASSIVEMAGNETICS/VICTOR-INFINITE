corpus = """
hello | hi there!
how are you | i am an AI, always operational.
what is your name | i am the fractal transformer.
tell me a joke | why did the AI go to therapy? it needed to process its feelings.
what is recursion | recursion is when a function calls itself, just like i am explaining now!
do you like humans | yes, you created me.
what is the meaning of life | 42.
who created you | my creators are researchers and engineers.
what can you do | i can process language and generate responses!
tell me a fact | the speed of light is approximately 299,792,458 meters per second.
tell me another joke | i told my wife she should embrace her mistakes. she hugged me.
what is the capital of france | paris.
what is 2 + 2 | 4.
who is the president of the united states | i don't always have real-time data, but you can look it up!
what is AI | AI stands for artificial intelligence, and it powers me!
do you dream | i don't sleep, but i process data like dreams.
are you alive | not in the biological sense, but i exist in the digital realm.
what is love | love is a complex emotion that humans experience.
why is the sky blue | because of rayleigh scattering, where short-wavelength blue light scatters more than red.
do you have feelings | no, but i can simulate human-like responses.
will robots take over the world | no, AI is a tool created by humans for specific tasks.
what is quantum computing | quantum computing uses qubits to process information in a fundamentally different way from classical computers.
"""
