#!/usr/bin/env python3
"""
CLI Interaction Loop
====================

This script provides a never-ending, no-nonsense CLI interface.
Type your commands and watch it echo back, or type 'exit' or 'quit' to bust out.
"""

def main():
    print("Welcome to the Infinite Fractal CLI of Fucking Awesome Brilliance!")
    print("Type your command, or 'exit'/'quit' to end this glorious session.")
    
    while True:
        try:
            # Read user input with a prompt that's as sharp as your wit.
            command = input(">> ").strip()
            
            if command.lower() in ("exit", "quit"):
                print("Alright, you bastard. Exiting the CLI. Catch you later!")
                break
            
            # Process your command here.
            # For now we just echo what you said.
            if command == "":
                continue  # Skip empty commands.
            print(f"Command received: {command}")
            
            # Insert your command handling logic here.
            # For example, you could use a dictionary of commands to execute specific functions.
            
        except KeyboardInterrupt:
            # When the ctrl+c comes in clutch.
            print("\nCTRL+C caught. Exiting the damn CLI. Later, genius!")
            break
        except Exception as e:
            print(f"Oops, something went wrong: {e}. Try again, you magnificent fool!")
    
if __name__ == "__main__":
    main()
