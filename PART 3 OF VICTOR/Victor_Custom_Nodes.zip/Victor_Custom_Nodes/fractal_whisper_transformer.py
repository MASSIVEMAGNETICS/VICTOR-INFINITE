# File: fractal_whisper_transformer.py
# Version: v1.1.0 – FRACTAL-NARRATOR PRIME

import torch
import torch.nn as nn
import traceback

class FractalWhisperTransformer(nn.Module):
    VERSION = "v1.1.0 – FRACTAL-NARRATOR PRIME"

    def __init__(self, input_dim=80, d_model=256, nhead=4, num_layers=6, num_tokens=1000, dropout=0.1):
        super().__init__()
        self.input_dim = input_dim
        self.d_model = d_model
        self.token_dim = num_tokens

        self.input_proj = nn.Linear(input_dim, d_model)
        self.pos_enc = self._build_positional_encoding(d_model)

        self.transformer = nn.Transformer(
            d_model=d_model,
            nhead=nhead,
            num_encoder_layers=num_layers,
            num_decoder_layers=num_layers,
            dim_feedforward=512,
            dropout=dropout,
            batch_first=True
        )

        self.token_head = nn.Linear(d_model, num_tokens)

    def _build_positional_encoding(self, d_model, max_len=1000):
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len).unsqueeze(1).float()
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-torch.log(torch.tensor(10000.0)) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        return pe.unsqueeze(0)  # shape (1, max_len, d_model)

    def forward(self, audio_features: torch.Tensor, mood_vector: torch.Tensor = None, intent_vector: torch.Tensor = None):
        try:
            if audio_features.dim() != 3:
                raise ValueError("audio_features must be shape (B, C, T)")

            B, C, T = audio_features.shape
            x = audio_features.transpose(1, 2)  # -> (B, T, C)

            if C != self.input_dim:
                raise ValueError(f"Expected {self.input_dim} channels, got {C}")

            x = self.input_proj(x)
            x = x + self.pos_enc[:, :x.size(1), :].to(x.device)

            tgt = torch.zeros(B, 1, self.d_model).to(x.device)

            if mood_vector is not None and mood_vector.shape[-1] == self.d_model:
                mood_bias = mood_vector.unsqueeze(1).expand_as(x)
                x = x + mood_bias

            if intent_vector is not None and intent_vector.shape[-1] == self.d_model:
                intent_mod = 1.0 + (intent_vector.unsqueeze(1) * 0.1)
                x = x * intent_mod.expand_as(x)

            transformer_out = self.transformer(x, tgt)
            logits = self.token_head(transformer_out)

            return logits  # shape (B, 1, num_tokens)

        except Exception as e:
            print(f"[FRACTAL WHISPER ERROR] {e}")
            print(traceback.format_exc())
            return torch.zeros(1, 1, self.token_dim)

# Run check
if __name__ == "__main__":
    model = FractalWhisperTransformer()
    dummy_audio = torch.randn(1, 80, 200)
    dummy_mood = torch.randn(1, 256)
    dummy_intent = torch.randn(1, 256)
    out = model(dummy_audio, dummy_mood, dummy_intent)
    print("Output shape:", out.shape)
