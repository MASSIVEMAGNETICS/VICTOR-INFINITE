# fractal_attention.py
# VICTOR OMNIFRACTAL GENESIS 5.0 – FRACTAL ATTENTION CORE
# Architect: Brandon & Tori

import torch
import torch.nn as nn
import torch.nn.functional as F
from error_sentinel import safe_execute

class FractalAttention(nn.Module):
    """
    God-Tier Recursive Fractal Attention
    Entropy-Aware | Self-Healing | Adaptive Recursion
    """

    def __init__(self, embed_dim=512, num_heads=8, max_depth=4, entropy_threshold=0.8):
        super().__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.max_depth = max_depth
        self.entropy_threshold = entropy_threshold

        self.qkv_proj = nn.Linear(embed_dim, embed_dim * 3)
        self.output_proj = nn.Linear(embed_dim, embed_dim)

        self.fail_safe = safe_execute

    def attention_entropy(self, attn_weights):
        """
        Compute normalized entropy of attention weights.
        """
        entropy = -torch.sum(attn_weights * attn_weights.log(), dim=-1)
        max_entropy = torch.log(torch.tensor(attn_weights.size(-1), dtype=torch.float))
        return (entropy / max_entropy).mean()

    def fractal_recursive_attention(self, x, depth=0):
        """
        Perform recursive attention with entropy-aware pruning.
        """
        B, T, D = x.shape
        qkv = self.qkv_proj(x).view(B, T, 3, self.num_heads, D // self.num_heads).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]

        scores = (q @ k.transpose(-2, -1)) * (D ** -0.5)
        attn_weights = F.softmax(scores, dim=-1)
        entropy = self.attention_entropy(attn_weights)

        out = (attn_weights @ v).transpose(1, 2).reshape(B, T, D)

        # Recursion control
        if entropy < self.entropy_threshold and depth < self.max_depth:
            deeper_out = self.fractal_recursive_attention(out, depth + 1)
            return out + deeper_out  # Residual merge
        else:
            return out

    def forward(self, x):
        """
        Full forward pass with error resilience.
        """
        try:
            attn_out = self.fractal_recursive_attention(x)
            return self.output_proj(attn_out)
        except Exception as e:
            return self.fail_safe(e, fallback_shape=x.shape)


# === Example Usage ===
if __name__ == "__main__":
    model = FractalAttention(embed_dim=512, num_heads=8, max_depth=4)
    dummy_input = torch.randn(2, 128, 512)
    output = model(dummy_input)
    print("Fractal Attention Output Shape:", output.shape)