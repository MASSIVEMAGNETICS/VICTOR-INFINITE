# File: comfyui_wrappers/fractal_neurocore_node.py
# Description: Unified recursive cognitive node with mood, memory, thought, and generation

from typing import List, Tuple, Dict
import torch
import json
from generate_response import generate_response
from Fractal_Tokenizer import FractalTokenizer
from fractal_memory_node import FractalMemoryNode

class FractalNeuroCoreNode:
    VERSION = "v1.0.0 – NEUROCORE"
    CATEGORY = "Fractal/Unified"
    FUNCTION = "neurocore"

    def __init__(self):
        self.tokenizer = FractalTokenizer(min_freq=1, max_depth=2)
        self.tokenizer.build_vocab("introspection recursion identity resonance context emotion")
        self.memory = FractalMemoryNode()

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "text_input": ("STRING", {}),
                "mood_vector": ("LIST", {}),
                "intent_tags": ("LIST", {}),
                "feeling_state": ("STRING", {}),
                "memory_trace": ("STRING", {}),
                "context_notes": ("STRING", {}),
                "user_profile": ("STRING", {}),
                "environmental_prompt": ("STRING", {}),
                "loop_depth": ("INT", {"default": 1, "min": 1, "max": 5})
            }
        }

    RETURN_TYPES = ("STRING", "LIST", "STRING", "STRING", "STRING")
    RETURN_NAMES = ("semantic_label", "fused_vector", "final_thought", "generative_output", "memory_log")

    def neurocore(self, text_input: str, mood_vector: List[float], intent_tags: List[str], feeling_state: str,
                  memory_trace: str, context_notes: str, user_profile: str, environmental_prompt: str, loop_depth: int
                  ) -> Tuple[str, List[float], str, str, str]:

        thought_output = ""
        semantic_label = f"Semantic-{intent_tags[0] if intent_tags else 'undefined'}"
        fused_vector = []
        memory_logs = []
        current_input = text_input

        for cycle in range(loop_depth):
            # Fuse vector
            base_vec = torch.tensor(mood_vector if mood_vector else [0.5, 0.5, 0.5])
            mod_scalar = len(intent_tags) + (1 if "reflect" in intent_tags else 0)
            fused_vector = torch.tanh(base_vec * mod_scalar).tolist()

            # Generate introspective thought
            thought_output = f"Cycle {cycle+1}: Reflecting on '{current_input}', mood={mood_vector}, intent={intent_tags}, tone={feeling_state}."

            # Generate response
            fused_prompt = f"User:{user_profile}\nEnvironment:{environmental_prompt}\nMemory:{memory_trace}\nContext:{context_notes}\nMood:{mood_vector}\nIntent:{intent_tags}\nFeeling:{feeling_state}\nThought:{thought_output}\nInput:{current_input}"
            text_output = generate_response(fused_prompt, max_length=50)

            # Log cycle
            log = json.dumps({
                "cycle": cycle + 1,
                "semantic_label": semantic_label,
                "thought": thought_output,
                "output": text_output,
                "mood": mood_vector,
                "intent": intent_tags,
                "feeling": feeling_state
            }, indent=2)

            self.memory.fractal_memory("log", "neurocore", log, "recursive_reflection", "", False, 1)
            memory_logs.append(log)

            current_input = text_output  # feed-forward into next loop

        return semantic_label, fused_vector, thought_output, text_output, memory_logs[-1]


NODE_CLASS_MAPPINGS = {
    "FractalNeuroCoreNode": FractalNeuroCoreNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "FractalNeuroCoreNode": "🧠 FractalNeuroCoreNode"
}
