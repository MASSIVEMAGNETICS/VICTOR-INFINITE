# File: bark_supreme_text_to_audio_node.py
# Version: v1.0.1-SCOS-E (Electron App Compatible)

import torch
import os
from generation import generate_text_semantic, generate_coarse, generate_fine, codec_decode, _grab_best_device
from config import SAMPLE_RATE

class BarkSupremeTextToAudioNode:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "text_prompt": ("STRING", {"default": "A poetic AI rapping about singularities."}),
                "voice_preset": ("STRING", {"default": "v2/en_speaker_6"}),
                "temperature": ("FLOAT", {"default": 0.7, "min": 0.0, "max": 1.5}),
                "length_scale": ("FLOAT", {"default": 1.0, "min": 0.5, "max": 2.0}),
            }
        }

    RETURN_TYPES = ("AUDIO", "INT")
    RETURN_NAMES = ("audio_tensor", "sample_rate")
    FUNCTION = "generate_audio"
    CATEGORY = "audio/generation"

    def generate_audio(self, text_prompt, voice_preset, temperature, length_scale):
        try:
            device = _grab_best_device()
            # Step 1: semantic tokens
            semantic_tokens = generate_text_semantic(
                text_prompt,
                history_prompt=voice_preset,
                temp=temperature,
                top_k=100,
                top_p=0.95,
                min_eos_p=0.2,
                max_gen_duration_s=14 * length_scale,
                allow_early_stop=True,
                device=device
            )
            # Step 2: coarse tokens
            coarse_tokens = generate_coarse(
                semantic_tokens,
                history_prompt=voice_preset,
                temp=temperature,
                device=device
            )
            # Step 3: fine tokens
            fine_tokens = generate_fine(
                coarse_tokens,
                history_prompt=voice_preset,
                temp=temperature,
                device=device
            )
            # Step 4: decode to waveform
            audio_array = codec_decode(fine_tokens, device=device)
            if audio_array.dim() == 1:
                audio_array = audio_array.unsqueeze(0)
            audio_tensor = audio_array.float().clamp(-1.0, 1.0)
            return (audio_tensor, SAMPLE_RATE)

        except Exception as e:
            print(f"[BarkSupreme::FatalError] {e}")
            dummy = torch.zeros(1, SAMPLE_RATE * 2)
            return (dummy, SAMPLE_RATE)

NODE_CLASS_MAPPINGS = {
    "BarkSupremeTextToAudioNode": BarkSupremeTextToAudioNode
}
NODE_DISPLAY_NAME_MAPPINGS = {
    "BarkSupremeTextToAudioNode": "Audio: Bark Supreme Text Generator"
}
