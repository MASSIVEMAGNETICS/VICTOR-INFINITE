# dossier_analyzer_v2.py
# Version: 2.0.0
# BANDO OPS — NEXT-GEN OSINT ANALYZER
# Features: NER Extraction, Contradiction Vector Logic, Intel Risk Score, Graph + Markdown Reporting

import os
import json
import spacy
import numpy as np
from datetime import datetime
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import networkx as nx
import matplotlib.pyplot as plt

# === CONFIG ===
TRANSCRIPTS_FOLDER = "transcripts/"
SOCIAL_POSTS_FILE = "social_posts.json"
REPORT_OUTPUT = "intel_dossier_v2.md"
SIMILARITY_THRESHOLD = 0.75

nlp = spacy.load("en_core_web_sm")

# === CORE UTILITIES ===

def load_text_files(folder):
    text_blocks = []
    for fname in os.listdir(folder):
        path = os.path.join(folder, fname)
        if os.path.isfile(path) and fname.endswith(".txt"):
            with open(path, "r", encoding="utf-8") as f:
                text_blocks.append(f.read())
    return text_blocks

def load_json(file):
    with open(file, "r", encoding="utf-8") as f:
        return json.load(f)

def extract_entities(text_blocks):
    entities = []
    for block in text_blocks:
        doc = nlp(block)
        entities += [ent.text for ent in doc.ents if ent.label_ in ("PERSON", "ORG", "GPE", "DATE")]
    return list(set(entities))

def vectorize_and_compare(transcripts, posts):
    all_text = transcripts + posts
    vectorizer = TfidfVectorizer().fit_transform(all_text)
    vectors = vectorizer.toarray()
    
    contradictions = []
    for i, t_vec in enumerate(vectors[:len(transcripts)]):
        for j, p_vec in enumerate(vectors[len(transcripts):]):
            sim = cosine_similarity([t_vec], [p_vec])[0][0]
            if sim > SIMILARITY_THRESHOLD:
                contradictions.append({
                    "transcript": transcripts[i],
                    "post": posts[j],
                    "score": sim
                })
    return contradictions

def build_entity_graph(entities):
    G = nx.Graph()
    for ent in entities:
        G.add_node(ent)
    for i in range(len(entities)):
        for j in range(i+1, len(entities)):
            G.add_edge(entities[i], entities[j])
    nx.draw(G, with_labels=True, node_color='lightblue', edge_color='gray', node_size=1800, font_size=10)
    plt.title("Entity Relationship Network")
    plt.savefig("network_graph_v2.png")
    plt.close()

def generate_markdown_report(entities, contradictions):
    with open(REPORT_OUTPUT, "w", encoding="utf-8") as f:
        f.write("# 🧠 INTEL DOSSIER v2.0\n")
        f.write(f"Generated: {datetime.now()}\n\n")
        f.write("## 🎯 Entities Detected\n")
        for ent in entities:
            f.write(f"- {ent}\n")
        f.write("\n## ❌ Potential Contradictions (Contextual)\n")
        for c in contradictions:
            f.write(f"- Similarity: {c['score']:.2f}\n")
            f.write(f"  - Transcript: `{c['transcript'][:100]}...`\n")
            f.write(f"  - Post: `{c['post'][:100]}...`\n\n")
        f.write("## 🔗 Entity Network\n")
        f.write("![Entity Graph](network_graph_v2.png)\n")
        f.write("\n## 📌 Notes:\n- Review contradictions for deception patterns.\n- High similarity = Potential denial or misinformation.\n")

# === EXECUTION FLOW ===

print("[*] Loading Data...")
transcripts = load_text_files(TRANSCRIPTS_FOLDER)
social_posts_data = load_json(SOCIAL_POSTS_FILE)
social_posts = [p["content"] for p in social_posts_data]

print("[*] Extracting Entities...")
entities = extract_entities(transcripts + social_posts)

print("[*] Analyzing Contradictions...")
contradictions = vectorize_and_compare(transcripts, social_posts)

print("[*] Building Graph...")
build_entity_graph(entities)

print("[*] Generating Report...")
generate_markdown_report(entities, contradictions)

print(f"[+] Dossier v2 Ready: {REPORT_OUTPUT}")
