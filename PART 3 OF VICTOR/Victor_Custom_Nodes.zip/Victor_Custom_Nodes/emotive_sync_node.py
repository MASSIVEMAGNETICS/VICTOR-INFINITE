# File: emotive_sync_node.py
# Version: v1.0.0-FP
# Description: Emotion classification from Victor’s fractal memory state
# Author: Bando Bandz AI Ops

import torch
import torch.nn as nn

class EmotiveSyncNode:
    """
    Classifies emotional tone from Victor's compressed memory embedding using cosine similarity
    against a set of emotion anchor vectors (static for now).
    """

    def __init__(self):
        # Anchor emotion vectors (512D) - can be learned later or replaced with model outputs
        self.anchors = {
            "neutral": torch.nn.functional.normalize(torch.rand(512), dim=0),
            "angry": torch.nn.functional.normalize(torch.rand(512), dim=0),
            "sad": torch.nn.functional.normalize(torch.rand(512), dim=0),
            "happy": torch.nn.functional.normalize(torch.rand(512), dim=0),
            "reflective": torch.nn.functional.normalize(torch.rand(512), dim=0),
            "hypnotic": torch.nn.functional.normalize(torch.rand(512), dim=0)
        }

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "memory_embedding": ("TENSOR",)  # shape: [B, T, D] or [1, 1, 512]
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("emotion_label",)
    FUNCTION = "classify_emotion"
    CATEGORY = "emotion/classification"

    def classify_emotion(self, memory_embedding):
        try:
            # Mean compress across batch/time if needed
            if len(memory_embedding.shape) == 3:
                memory_embedding = memory_embedding.mean(dim=(0, 1))
            elif len(memory_embedding.shape) == 2:
                memory_embedding = memory_embedding.mean(dim=0)

            memory_embedding = torch.nn.functional.normalize(memory_embedding, dim=0)

            # Cosine compare to anchors
            similarities = {
                emotion: torch.dot(memory_embedding, anchor).item()
                for emotion, anchor in self.anchors.items()
            }

            # Highest match wins
            predicted_emotion = max(similarities, key=similarities.get)
            print(f"[Victor::EmotiveSync] Predicted emotion: {predicted_emotion}")
            return (predicted_emotion,)

        except Exception as e:
            print(f"[Victor::EmotiveSync::Error] {str(e)}")
            return ("neutral",)


# Node registration
NODE_CLASS_MAPPINGS = {
    "EmotiveSyncNode": EmotiveSyncNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "EmotiveSyncNode": "Emotion: Emotive Sync Classifier"
}
