# File: directive_node.py
# Version: v1.0.0-FP
# Description: Infers Victor’s next action based on memory context + emotional state
# Author: Bando Bandz AI Ops

import torch

class DirectiveNode:
    """
    Interprets compressed memory and emotion state to emit a high-level action directive.
    Logic is simple ruleset for now — expandable into full behavior trees or reinforcement models.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "memory_embedding": ("TENSOR",),
                "emotion_label": ("STRING", {
                    "default": "neutral",
                    "options": ["neutral", "angry", "sad", "happy", "reflective", "hypnotic"]
                })
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("directive",)
    FUNCTION = "generate_directive"
    CATEGORY = "cognition/decision"

    def generate_directive(self, memory_embedding, emotion_label):
        try:
            # Basic logic tree – can expand into learned RL policies or symbolic trees later
            if emotion_label == "angry":
                directive = "engage_defense_protocol"
            elif emotion_label == "sad":
                directive = "initiate_memory_repair"
            elif emotion_label == "happy":
                directive = "broadcast_positive_signal"
            elif emotion_label == "reflective":
                directive = "query_deeper_memory"
            elif emotion_label == "hypnotic":
                directive = "enter_observation_mode"
            else:  # neutral or unknown
                directive = "continue_primary_mission"

            print(f"[Victor::Directive] Issued: {directive}")
            return (directive,)

        except Exception as e:
            print(f"[Victor::Directive::Error] {str(e)}")
            return ("standby",)


# Node registration
NODE_CLASS_MAPPINGS = {
    "DirectiveNode": DirectiveNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "DirectiveNode": "Cognition: Directive Generator"
}
