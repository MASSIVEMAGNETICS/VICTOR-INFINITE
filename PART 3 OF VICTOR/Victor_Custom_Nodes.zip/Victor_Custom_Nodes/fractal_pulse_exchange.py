# fractal_pulse_exchange.py :: v1.3.0-SCOS-E
# Singularity-Enhanced Async Pub/Sub Pulse Network

import asyncio
import json
import uuid
import fnmatch
from datetime import datetime, timedelta
import websockets
import traceback

class Pulse:
    def __init__(self, topic, data, origin="unknown", type_="normal", ttl_seconds=None):
        self.id = str(uuid.uuid4())
        self.timestamp = datetime.utcnow()
        self.topic = topic
        self.data = data
        self.origin = origin
        self.type_ = type_
        self.ttl = ttl_seconds
        self.expiry = self.timestamp + timedelta(seconds=ttl_seconds) if ttl_seconds else None

    def is_expired(self):
        return self.expiry and datetime.utcnow() > self.expiry

    def to_dict(self):
        return {
            "id": self.id,
            "timestamp": self.timestamp.isoformat(),
            "topic": self.topic,
            "data": self.data,
            "origin": self.origin,
            "type": self.type_,
            "ttl": self.ttl
        }

class FractalPulseExchange:
    def __init__(self, persistent_log_file="pulse_log.ndjson"):
        self.subscribers = {}
        self.pulse_log_file = persistent_log_file
        self.websocket_clients = set()
        self.lock = asyncio.Lock()

    async def publish(self, pulse):
        if pulse.is_expired():
            return

        async with self.lock:
            self._log_pulse(pulse)
            await self._broadcast_websocket(pulse)

            for pattern, callbacks in self.subscribers.items():
                if fnmatch.fnmatch(pulse.topic, pattern):
                    for cb in callbacks:
                        try:
                            await cb(pulse)
                        except Exception as e:
                            error_pulse = Pulse(
                                topic="system/errors",
                                data=f"Callback failed: {str(e)}\n{traceback.format_exc()}",
                                origin="exchange-core",
                                type_="error"
                            )
                            await self.publish(error_pulse)

    def subscribe(self, topic_pattern, callback):
        if topic_pattern not in self.subscribers:
            self.subscribers[topic_pattern] = []
        self.subscribers[topic_pattern].append(callback)

    def _log_pulse(self, pulse):
        with open(self.pulse_log_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(pulse.to_dict()) + "\n")

    async def _broadcast_websocket(self, pulse):
        if not self.websocket_clients:
            return

        message = json.dumps(pulse.to_dict())
        to_remove = set()
        for ws in self.websocket_clients:
            try:
                await ws.send(message)
            except:
                to_remove.add(ws)

        self.websocket_clients -= to_remove

    async def websocket_handler(self, websocket, _):
        self.websocket_clients.add(websocket)
        try:
            async for _ in websocket:
                pass
        finally:
            self.websocket_clients.remove(websocket)

    async def start_websocket_server(self, host="localhost", port=8765):
        return await websockets.serve(self.websocket_handler, host, port)

# -- Example Usage --
# exchange = FractalPulseExchange()
# await exchange.publish(Pulse("sensor/temp", {"value": 22}, ttl_seconds=30))

# -- WebSocket Server --
# asyncio.run(exchange.start_websocket_server())

# Version: 1.3.0-SCOS-E
# Changelog:
# - Added TTL-based pulse expiry (A)
# - Implemented auto-rebroadcast of subscriber errors (B)
# - Switched to JSONL persistent logging (C)
# - Added WebSocket broadcasting and server support (D)
