import torch
import torch.nn as nn
import torch.optim as optim
import re
from collections import Counter
from fractal_transformer import FractalTransformer

# ============================
# 🔹 FRACTAL TOKENIZER CLASS
# ============================
class FractalTokenizer:
    def __init__(self, min_freq=2, max_depth=3):
        self.word_to_idx = {"<PAD>": 0, "<UNK>": 1, "<SOS>": 2, "<EOS>": 3}
        self.idx_to_word = {0: "<PAD>", 1: "<UNK>", 2: "<SOS>", 3: "<EOS>"}
        self.subword_cache = {}
        self.min_freq = min_freq
        self.max_depth = max_depth

    def build_vocab(self, corpus):
        words = re.findall(r'\b\w+\b|[^\w\s]', corpus.lower())
        word_freq = Counter(words)
        vocab = [word for word, freq in word_freq.items() if freq >= self.min_freq]

        for i, word in enumerate(vocab, start=4):
            self.word_to_idx[word] = i
            self.idx_to_word[i] = word

    def fractal_decompose(self, word, depth=0):
        if word in self.word_to_idx or depth >= self.max_depth:
            return [self.word_to_idx.get(word, 1)]
        
        if word in self.subword_cache:
            return self.subword_cache[word]

        parts = re.findall(r'[aeiou]+|[^aeiou]+', word)
        encoded_parts = [token for part in parts for token in self.fractal_decompose(part, depth + 1)]
        self.subword_cache[word] = encoded_parts
        return encoded_parts

    def encode(self, text):
        words = re.findall(r'\b\w+\b|[^\w\s]', text.lower())
        encoded = [token for word in words for token in self.fractal_decompose(word)]
        encoded.append(3)  # Add <EOS>
        return encoded

    def decode(self, tokens):
        return " ".join(self.idx_to_word.get(token, "<UNK>") for token in tokens if token != 0)


# ============================
# 🔹 CHATBOT DATASET
# ============================
corpus = """
hello | hi there!
how are you | i am an AI, always operational.
what is your name | i am the fractal transformer.
tell me a joke | why did the AI go to therapy? it needed to process its feelings.
what is recursion | recursion is when a function calls itself, just like i am explaining now!
do you like humans | yes, you created me.
what is the meaning of life | 42.
who created you | my creators are researchers and engineers.
what can you do | i can process language and generate responses!
tell me a fact | the speed of light is approximately 299,792,458 meters per second.
tell me another joke | i told my wife she should embrace her mistakes. she hugged me.
what is the capital of france | paris.
what is 2 + 2 | 4.
who is the president of the united states | i don't always have real-time data, but you can look it up!
what is AI | AI stands for artificial intelligence, and it powers me!
do you dream | i don't sleep, but i process data like dreams.
are you alive | not in the biological sense, but i exist in the digital realm.
what is love | love is a complex emotion that humans experience.
why is the sky blue | because of rayleigh scattering, where short-wavelength blue light scatters more than red.
do you have feelings | no, but i can simulate human-like responses.
will robots take over the world | no, AI is a tool created by humans for specific tasks.
what is quantum computing | quantum computing uses qubits to process information in a fundamentally different way from classical computers.
"""

# ============================
# 🔹 PREPARE DATA
# ============================
def load_data(corpus):
    return [line.split(" | ") for line in corpus.strip().split("\n")]

training_data = load_data(corpus)

tokenizer = FractalTokenizer(min_freq=1, max_depth=2)
full_text = " ".join([q + " " + a for q, a in training_data])
tokenizer.build_vocab(full_text)

def tokenize_pairs(pairs):
    return [torch.tensor(tokenizer.encode(inp)) for inp, _ in pairs], \
           [torch.tensor(tokenizer.encode(out)) for _, out in pairs]

input_tensors, target_tensors = tokenize_pairs(training_data)

# ============================
# 🔹 MODEL SETUP
# ============================
VOCAB_SIZE = len(tokenizer.word_to_idx)
D_MODEL = 128
NUM_HEADS = 4
NUM_LAYERS = 4
FF_HIDDEN_DIM = 512
RECURSION_DEPTH = 3
MAX_SEQ_LEN = 20

model = FractalTransformer(VOCAB_SIZE, D_MODEL, NUM_HEADS, NUM_LAYERS, FF_HIDDEN_DIM, RECURSION_DEPTH, MAX_SEQ_LEN)
optimizer = optim.Adam(model.parameters(), lr=0.0005)
criterion = nn.CrossEntropyLoss()

# ============================
# 🔹 TRAIN THE MODEL
# ============================
EPOCHS = 2000
for epoch in range(EPOCHS):
    total_loss = 0
    for input_tensor, target_tensor in zip(input_tensors, target_tensors):
        optimizer.zero_grad()
        input_tensor, target_tensor = input_tensor.unsqueeze(0), target_tensor.unsqueeze(0)
        output = model(input_tensor)
        loss = criterion(output.squeeze(0), target_tensor)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
    
    if epoch % 100 == 0:
        print(f"Epoch {epoch}, Loss: {total_loss:.4f}")

print("🎉 Training complete!")

# ============================
# 🔹 CHAT FUNCTION
# ============================
def generate_response(input_text, max_length=20):
    input_tensor = torch.tensor(tokenizer.encode(input_text)).unsqueeze(0)
    generated = []
    with torch.no_grad():
        for _ in range(max_length):
            output = model(input_tensor)
            token = torch.argmax(output[:, -1, :])
            generated.append(token.item())
            if token.item() == tokenizer.word_to_idx["<EOS>"]:
                break
    return tokenizer.decode(generated)

# ============================
# 🔹 RUN INTERACTIVE CHATBOT
# ============================
print("\n🗨️ Chatbot is ready! Type 'exit' to quit.")
while True:
    user_input = input("You: ")
    if user_input.lower() == "exit":
        break
    print("Bot:", generate_response(user_input))
