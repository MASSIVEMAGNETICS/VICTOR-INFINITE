# File: comfyui_wrappers/thought_loop_router_node.py
# Purpose: Routes recursive thoughts back into cognition or tokenizer loop

from typing import Tuple, Dict

class ThoughtLoopRouterNode:
    VERSION = "v1.0.0 – LOOP-RECURSOR"
    CATEGORY = "Fractal/Cognition"
    FUNCTION = "loop_thought"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "thought": ("STRING", {}),
                "route_to": ("STRING", {"default": "FractalCognitionNode", "options": ["FractalCognitionNode", "FractalTokenizerNode"]})
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("loop_input",)

    def loop_thought(self, thought: str, route_to: str) -> Tuple[str]:
        prefix = {
            "FractalCognitionNode": "Recursive Reflection: ",
            "FractalTokenizerNode": "Tokenize Insight: "
        }.get(route_to, "Thought: ")

        return (f"{prefix}{thought}",)


NODE_CLASS_MAPPINGS = {
    "ThoughtLoopRouterNode": ThoughtLoopRouterNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "ThoughtLoopRouterNode": "🔁 ThoughtLoopRouter"
}
