# File: comprehension_node.py
# Version: v1.1.0-FP
# Description: Comprehension engine with structured causal + contradiction output
# Author: Bando Bandz AI Ops

class ComprehensionNode:
    """
    Synthesizes understanding from a list of memory or narrative strings.
    Returns structured output including insights, contradiction flags, and causal links.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "input_chunks": ("STRING", {"multiline": True}),
                "source_type": ("STRING", {
                    "default": "memory",
                    "options": ["memory", "directive", "narrative"]
                })
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("structured_comprehension",)
    FUNCTION = "synthesize_understanding"
    CATEGORY = "cognition/comprehension"

    def synthesize_understanding(self, input_chunks, source_type):
        try:
            entries = [e.strip() for e in input_chunks.split("\n\n") if e.strip()]
            insights = []
            contradictions = []
            causality = []

            for i, entry in enumerate(entries):
                # Detect contradiction
                if any(w in entry.lower() for w in ["not", "but", "however", "yet"]):
                    contradictions.append({"entry": i+1, "text": entry})

                # Detect causality
                if any(w in entry.lower() for w in ["caused", "led to", "resulted in", "therefore"]):
                    causality.append({"entry": i+1, "text": entry})

                # Summarize
                insight = self._summarize(entry)
                insights.append({"entry": i+1, "summary": insight})

            response = {
                "source_type": source_type,
                "total_entries": len(entries),
                "insights": insights,
                "contradictions": contradictions,
                "causal_links": causality
            }

            return (str(response),)

        except Exception as e:
            print(f"[Victor::ComprehensionNode::Error] {str(e)}")
            return ("[Error] Failed to synthesize understanding.",)

    def _summarize(self, text):
        if len(text) <= 120:
            return text
        return text[:100].strip() + "..."


# Node registration
NODE_CLASS_MAPPINGS = {
    "ComprehensionNode": ComprehensionNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "ComprehensionNode": "Cognition: Comprehension Synthesizer (Structured)"
}
