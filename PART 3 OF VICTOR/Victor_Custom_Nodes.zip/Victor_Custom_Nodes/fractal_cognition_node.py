# File: comfyui_wrappers/fractal_cognition_node.py
# Unified text-to-text generation using fractal tokenizer + transformer + decoder
# Enhanced: Mood feedback, confidence scoring, memory logging, intent adaptation

from typing import Tuple
from Fractal_Tokenizer import FractalTokenizer
from generate_response import generate_response
from fractal_chatbot import model as pretrained_model
from fractal_memory_node import FractalMemoryNode
import json
import torch

class FractalCognitionNode:
    VERSION = "v1.2.0-COMFY-COGNITIVE"
    CATEGORY = "Fractal/Cognition"
    FUNCTION = "cogenerate"

    def __init__(self):
        self.tokenizer = FractalTokenizer(min_freq=1, max_depth=2)
        self.tokenizer.build_vocab("hello fractal recursion transformation silence language emotions")
        self.model = pretrained_model
        self.memory = FractalMemoryNode()

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "text": ("STRING", {"default": "What is the meaning of life?"}),
                "max_length": ("INT", {"default": 20, "min": 1, "max": 100})
            }
        }

    RETURN_TYPES = ("STRING", "FLOAT")
    RETURN_NAMES = ("response", "confidence_score")

    def cogenerate(self, text: str, max_length: int) -> Tuple[str, float]:
        # 🧠 Memory Feedback Hook
        memory_result = self.memory.fractal_memory("query", "token_snapshot", "", "tokenizer_output", "What mood has dominated recently?", False, 1)[0]

        try:
            data = json.loads(memory_result.split("---")[-1])
            last_moods = [t.get("metadata", {}).get("mood_influence") for t in data.get("tokens", []) if isinstance(t.get("metadata", {}).get("mood_influence"), list)]
            last_intents = [t.get("metadata", {}).get("intent_influence") for t in data.get("tokens", []) if isinstance(t.get("metadata", {}).get("intent_influence"), list)]

            mood_vector = last_moods[-1] if last_moods else []
            intent_tags = last_intents[-1] if last_intents else []
        except:
            mood_vector = []
            intent_tags = []

        input_tensor = self.tokenizer.encode(text)
        generated = []
        input_tensor = torch.tensor(input_tensor).unsqueeze(0)

        with torch.no_grad():
            for _ in range(max_length):
                output = self.model(input_tensor)
                token = torch.argmax(output[:, -1, :])
                generated.append(token.item())
                if token.item() == self.tokenizer.word_to_idx["<EOS>"]:
                    break

        response = self.tokenizer.decode(generated)
        avg_len = sum(len(self.tokenizer.idx_to_word.get(t, "")) for t in generated) / len(generated) if generated else 0
        confidence_score = round(min(avg_len / 8, 1.0), 3)

        # 📝 Memory Log Hook
        log_content = json.dumps({
            "prompt": text,
            "generated": response,
            "mood_vector": mood_vector,
            "intent_tags": intent_tags,
            "tokens": generated,
            "confidence": confidence_score
        }, indent=2)

        self.memory.fractal_memory("log", "cognition_result", log_content, "response_log", "", False, 1)

        return response, confidence_score


# Register node
NODE_CLASS_MAPPINGS = {
    "FractalCognitionNode": FractalCognitionNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "FractalCognitionNode": "🧠 FractalCognitionNode"
}
