import torch
import torch.nn as nn
import torch.nn.functional as F

class FractalFeedForward(nn.Module):
    def __init__(self, d_model, hidden_dim, recursion_depth=2):
        super().__init__()
        self.recursion_depth = recursion_depth
        self.fc1 = nn.Linear(d_model, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, d_model)
        self.activation = nn.ReLU()
    
    def recursive_ffn(self, x, depth, cache=None):
        if cache is None:
            cache = {}
        
        if depth == 0:
            return self.fc2(self.activation(self.fc1(x)))
        
        if depth in cache:
            return cache[depth]
        
        mid = self.recursive_ffn(x, depth - 1, cache)
        cache[depth] = (mid + self.recursive_ffn(x, depth - 1, cache)) / 2
        return cache[depth]
    
    def forward(self, x):
        return self.recursive_ffn(x, self.recursion_depth).to(x.device)
