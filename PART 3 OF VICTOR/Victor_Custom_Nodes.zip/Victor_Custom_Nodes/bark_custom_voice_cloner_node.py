# File: bark_custom_voice_cloner_node.py
# Version: v1.2.0-FP
# Description: Clones and saves Victor’s voice embeddings with full fault tolerance and modularity
# Author: Bando Bandz AI Ops

import os
import torch
import numpy as np
from clonevoice import clone_voice_embedding  # Assumed available in local system
from config import SAMPLE_RATE

class BarkCustomVoiceCloneNode:
    """
    Clones a voice embedding from an input audio tensor and saves it to .npz or .pt format.
    Includes safety checks, overwrite protection, and audio normalization options.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "audio_tensor": ("AUDIO",),
                "sample_rate": ("INT", {"default": SAMPLE_RATE}),
                "voice_name": ("STRING", {"default": "my_voice"}),
                "save_path": ("STRING", {"default": "custom_voices/"}),
                "file_format": ("STRING", {
                    "default": "npz",
                    "options": ["npz", "pt"]
                }),
                "force_overwrite": ("BOOLEAN", {"default": False}),
                "normalize_audio": ("BOOLEAN", {"default": True})
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("preset_path",)
    FUNCTION = "clone_voice"
    CATEGORY = "audio/voice_cloning"

    def clone_voice(self, audio_tensor, sample_rate, voice_name, save_path, file_format, force_overwrite, normalize_audio):
        try:
            os.makedirs(save_path, exist_ok=True)
            out_path = os.path.join(save_path, f"{voice_name}.{file_format}")

            if os.path.exists(out_path) and not force_overwrite:
                raise FileExistsError(f"[Victor::VoiceClone] File exists: {out_path} — Set 'force_overwrite' to True.")

            if audio_tensor is None or len(audio_tensor.shape) < 2:
                raise ValueError("[Victor::VoiceClone] Invalid or empty audio tensor input.")

            # Force mono if stereo
            if audio_tensor.shape[0] > 1:
                audio_tensor = torch.mean(audio_tensor, dim=0, keepdim=True)

            # Normalize if needed
            if normalize_audio:
                max_val = torch.max(torch.abs(audio_tensor))
                if max_val > 0:
                    audio_tensor = audio_tensor / max_val

            # Generate voice embedding
            embedding = clone_voice_embedding(audio_tensor.squeeze(), sample_rate)

            # Save to specified format
            if file_format == "npz":
                np.savez(out_path, embedding.numpy())
            elif file_format == "pt":
                torch.save(embedding, out_path)
            else:
                raise ValueError(f"[Victor::VoiceClone] Unsupported file format: {file_format}")

            print(f"[Victor::VoiceClone] Saved embedding: {out_path}")
            return (out_path,)

        except FileExistsError as fe:
            print(f"[Victor::VoiceClone::Exists] {str(fe)}")
            return ("",)

        except Exception as e:
            print(f"[Victor::VoiceClone::Error] {str(e)}")
            return ("",)


# Node Registration
NODE_CLASS_MAPPINGS = {
    "BarkCustomVoiceCloneNode": BarkCustomVoiceCloneNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "BarkCustomVoiceCloneNode": "Audio: Custom Voice Cloner"
}
