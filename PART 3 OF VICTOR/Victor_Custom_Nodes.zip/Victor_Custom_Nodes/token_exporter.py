# token_exporter.py :: VERSION 1.0.0-SCOS-E
import json
import csv
import zipfile
from typing import List, Dict, Optional
from pathlib import Path
from datetime import datetime

EXPORT_PATH = Path("./exports")
EXPORT_PATH.mkdir(exist_ok=True)

def export_tokens(tokens: List[Dict], basename: str, zip_enabled: bool = False) -> Dict[str, Optional[Path]]:
    """
    Export a list of token dictionaries to JSON and CSV, optionally compressing to ZIP.

    Parameters:
    - tokens (List[Dict]): List of dictionaries containing token data.
    - basename (str): Base name for export files.
    - zip_enabled (bool): Whether to compress exports into a ZIP file.

    Returns:
    - Dict[str, Optional[Path]]: Paths to the exported files.
    """
    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    json_file = EXPORT_PATH / f"{basename}_{timestamp}.json"
    csv_file = EXPORT_PATH / f"{basename}_{timestamp}.csv"
    zip_path = EXPORT_PATH / f"{basename}_{timestamp}.zip" if zip_enabled else None

    try:
        # Export JSON
        with open(json_file, "w", encoding="utf-8") as jf:
            json.dump(tokens, jf, indent=2)
        print(f"✅ JSON exported to {json_file}")

        # Export CSV
        keys = sorted({k for token in tokens for k in token})
        with open(csv_file, "w", encoding="utf-8", newline='') as cf:
            writer = csv.DictWriter(cf, fieldnames=keys)
            writer.writeheader()
            for token in tokens:
                writer.writerow(token)
        print(f"✅ CSV exported to {csv_file}")

        # Optional ZIP Compression
        if zip_enabled:
            with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as zipf:
                zipf.write(json_file, arcname=json_file.name)
                zipf.write(csv_file, arcname=csv_file.name)
            print(f"🗜️ ZIP archived to {zip_path}")

        return {
            "json_path": json_file,
            "csv_path": csv_file,
            "zip_path": zip_path
        }

    except Exception as e:
        print(f"❌ Export failed: {e}")
        return {
            "json_path": None,
            "csv_path": None,
            "zip_path": None
        }
