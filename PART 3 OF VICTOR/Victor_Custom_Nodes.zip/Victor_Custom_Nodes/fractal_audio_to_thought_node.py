# File: comfyui_wrappers/fractal_audio_to_thought_node.py
# Description: GOD-TIER full-stack Fractal audio cognition node — resilient Audio → Thought Reflection

import torch
from fractal_audio_encoder import FractalAudioEncoder
from fractal_whisper_transformer import FractalWhisperTransformer
from fractal_thought_decoder import FractalThoughtDecoder
from typing import Tuple, Dict
import traceback
import os

class FractalAudioToThoughtNode:
    VERSION = "v1.1.0 – FRACTAL-AUDIO-REFLECTOR (GOD-TIER)"
    CATEGORY = "Fractal/Audio"
    FUNCTION = "audio_to_thought"

    def __init__(self):
        try:
            self.encoder = FractalAudioEncoder()
            self.model = FractalWhisperTransformer()
            vocab = {"echo": 0, "silence": 1, "self": 2, "identity": 3, "thought": 4, "<unk>": 999}
            self.decoder = FractalThoughtDecoder(vocab)
        except Exception as e:
            raise RuntimeError(f"Initialization failed: {str(e)}")

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "audio_file_path": ("STRING", {}),
                "mood_vector": ("LIST", {"default": [0.4] * 256}),
                "intent_vector": ("LIST", {"default": [0.2] * 256})
            }
        }

    RETURN_TYPES = ("STRING", "DICT")
    RETURN_NAMES = ("thought", "metadata")

    def audio_to_thought(self, audio_file_path: str, mood_vector: list, intent_vector: list) -> Tuple[str, Dict]:
        try:
            if not os.path.exists(audio_file_path):
                raise FileNotFoundError(f"Audio path not found: {audio_file_path}")

            mel_tensor = self.encoder.process_file(audio_file_path).unsqueeze(0)  # shape (1, 80, T)
            mood = torch.tensor(mood_vector).unsqueeze(0)
            intent = torch.tensor(intent_vector).unsqueeze(0)

            logits = self.model(mel_tensor, mood_vector=mood, intent_vector=intent)
            thought = self.decoder(logits)

            return thought, {
                "shape": mel_tensor.shape,
                "thought": thought,
                "mood_vector_used": mood_vector,
                "intent_vector_used": intent_vector
            }

        except Exception as e:
            fallback_thought = f"[ERROR] Failed to reflect: {str(e)}"
            error_trace = traceback.format_exc()
            return fallback_thought, {
                "error": str(e),
                "traceback": error_trace,
                "fallback": True,
                "mood_vector_used": mood_vector,
                "intent_vector_used": intent_vector
            }


NODE_CLASS_MAPPINGS = {
    "FractalAudioToThoughtNode": FractalAudioToThoughtNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "FractalAudioToThoughtNode": "🧠 FractalAudioToThought (GOD-TIER)"
}
