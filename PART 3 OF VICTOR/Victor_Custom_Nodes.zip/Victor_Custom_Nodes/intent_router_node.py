# File: intent_router_node.py
# Version: v0.1.0 - INTENT-GUIDED ROUTING
# Description: Dynamically routes token streams to target nodes based on dominant intent weights from memory.

from typing import List, Dict, Tuple
import json
from fractal_memory_node import FractalMemoryNode

class IntentRouterNode:
    """
    Routes token data based on dominant semantic intent from memory logs.

    Inputs:
        - tokens (List[dict]): Token stream to inspect
        - routing_table (dict[str, str]): Maps intent tag to downstream node ID
        - fallback_node (str): Default node ID if no match is found

    Outputs:
        - routed_node_id (str): ID of the node to send tokens to
        - dominant_intent (str): Matched dominant intent tag
        - diagnostics (dict): Metadata on routing logic

    Version: v0.1.0 - INTENT-GUIDED ROUTING
    """

    VERSION = "v0.1.0 - INTENT-GUIDED ROUTING"
    CATEGORY = "Victor/Cognition"
    FUNCTION = "route_by_intent"

    def __init__(self):
        self.memory = FractalMemoryNode()

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "tokens": ("LIST", {}),
                "routing_table": ("DICT", {}),
                "fallback_node": ("STRING", {"default": "AutoencoderReflectorNode"})
            }
        }

    RETURN_TYPES = ("STRING", "STRING", "DICT")
    RETURN_NAMES = ("routed_node_id", "dominant_intent", "diagnostics")

    def route_by_intent(self, tokens: List[Dict], routing_table: Dict[str, str], fallback_node: str) -> Tuple[str, str, Dict]:
        query_payload = json.dumps({"tokens": tokens}, indent=2)
        memory_result = self.memory.fractal_memory("query", "token_snapshot", "", "tokenizer_output", "What intent is currently dominant?", False, 3)[0]

        intent_weights = {}
        try:
            lines = memory_result.split("\n")
            for line in lines:
                if "`" in line and "*" in line:
                    tag = line.split("`")[-2]
                    intent_weights[tag] = intent_weights.get(tag, 0) + 1
        except:
            pass

        dominant_intent = max(intent_weights.items(), key=lambda x: x[1])[0] if intent_weights else "unknown"
        routed_node_id = routing_table.get(dominant_intent, fallback_node)

        diagnostics = {
            "dominant_intent": dominant_intent,
            "intent_weights": intent_weights,
            "routing_decision": routed_node_id
        }

        return routed_node_id, dominant_intent, diagnostics
