# File: comprehension_node.py
# Version: v1.0.0-FP
# Description: Synthesizes meaning, flags contradictions, and reveals causal links from memory or directives
# Author: Bando Bandz AI Ops

class ComprehensionNode:
    """
    Synthesizes understanding from a list of memory or narrative strings.
    Outputs a structured insight summary, flags contradictions, and infers causal flow.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "input_chunks": ("STRING", {"multiline": True}),
                "source_type": ("STRING", {
                    "default": "memory",
                    "options": ["memory", "directive", "narrative"]
                })
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("comprehension_report",)
    FUNCTION = "synthesize_understanding"
    CATEGORY = "cognition/comprehension"

    def synthesize_understanding(self, input_chunks, source_type):
        try:
            entries = [e.strip() for e in input_chunks.split("\n\n") if e.strip()]
            insight_blocks = []
            contradictions = []
            causal_links = []

            for i, entry in enumerate(entries):
                if any(k in entry.lower() for k in ["not", "but", "however", "yet"]) and source_type != "directive":
                    contradictions.append(f"⚠️ Possible contradiction in entry {i+1}:\n{entry}")
                if any(k in entry.lower() for k in ["caused", "led to", "resulted in", "therefore"]):
                    causal_links.append(f"🔄 Causal detected in entry {i+1}:\n{entry}")

                # Primitive insight logic
                insight_blocks.append(f"🧠 Insight {i+1}: {self._summarize_line(entry)}")

            report = f"""
🧠 *Victor Comprehension Report*
-------------------------------
📥 Source Type: {source_type.upper()}
📦 Total Entries: {len(entries)}

📖 Extracted Insights:
{chr(10).join(insight_blocks)}

⚠️ Contradictions Detected:
{chr(10).join(contradictions) if contradictions else "None"}

🔄 Causal Relations:
{chr(10).join(causal_links) if causal_links else "None"}
""".strip()

            print(f"[Victor::Comprehension] Synthesized {len(entries)} entries.")
            return (report,)

        except Exception as e:
            print(f"[Victor::Comprehension::Error] {str(e)}")
            return ("[Error] Comprehension failed.",)

    def _summarize_line(self, line):
        # Simple summarizer: trim and extract action-object pairs (placeholder logic)
        if len(line) < 100:
            return line
        return line[:100] + "..."

# Node registration
NODE_CLASS_MAPPINGS = {
    "ComprehensionNode": ComprehensionNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "ComprehensionNode": "Cognition: Comprehension Synthesizer"
}
