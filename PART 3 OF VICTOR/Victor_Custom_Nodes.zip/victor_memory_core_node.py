# VictorMemoryCoreNode placeholder
class VictorMemoryCoreNode: pass