# EchoNode placeholder
class EchoNode: pass